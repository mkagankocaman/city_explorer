// lib/main.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:mapbox_maps_flutter/mapbox_maps_flutter.dart';
import 'data/database/app_database.dart';
import 'app.dart';

/// BUG 5 FIX:
/// We fully initialize the database (and check location permission) BEFORE
/// navigating away from the splash screen. The [runApp] call only happens
/// after [AppDatabase.instance.initialize()] completes, so there is no race
/// condition between splash dismissal and DB readiness.
///
/// Flutter's native splash screen stays visible until the first frame is
/// drawn. Because we await all async work inside main(), the splash remains
/// until the app is fully ready to render.
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Lock to portrait (optional — remove if you want landscape support)
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  // Set status bar style
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
  ));

  // ── BUG 5 FIX: DB init completes before we build the widget tree ───────
  await AppDatabase.instance.initialize();

  // ── Mapbox token: set from your environment or a constant ──────────────
  // Replace the empty string with your actual Mapbox public token.
  // Get one free at https://account.mapbox.com
  //
  // In production, load this from --dart-define or a .env file:
  //   flutter run --dart-define=MAPBOX_ACCESS_TOKEN=pk.eyJ1...
  const mapboxToken = String.fromEnvironment(
    'MAPBOX_ACCESS_TOKEN',
    defaultValue: 'pk.eyJ1IjoibWthZ2Fua29jYW1hbiIsImEiOiJjbXBqY28xMTEwcHdxMnhzNnFveG9tZGdoIn0.SstrkqVCkjMbX6lxaofOQA',
  );
  MapboxOptions.setAccessToken(mapboxToken);

  runApp(
    // ProviderScope is the root of all Riverpod providers.
    // Think of it as the "container" that holds all app state.
    const ProviderScope(
      child: CityGridApp(),
    ),
  );
}
