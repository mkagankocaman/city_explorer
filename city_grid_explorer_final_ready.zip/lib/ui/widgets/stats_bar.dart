// lib/ui/widgets/stats_bar.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/constants.dart';
import '../../providers/stats_provider.dart';
import '../../providers/session_provider.dart';
import '../../services/session_manager.dart' show SessionState;

/// Top bar overlaid on the map. Shows exploration % and active session indicator.
class StatsBar extends ConsumerWidget {
  const StatsBar({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final statsAsync = ref.watch(statsProvider);
    final sessionState = ref.watch(sessionProvider).sessionState;

    return Container(
      margin: const EdgeInsets.fromLTRB(12, 8, 12, 0),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        color: AppColors.surface.withAlpha(230),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: sessionState == SessionState.active
              ? AppColors.primary.withAlpha(128)
              : Colors.transparent,
          width: 1.5,
        ),
      ),
      child: Row(
        children: [
          // ── Exploration % ──────────────────────────────────────────
          Expanded(
            child: statsAsync.when(
              loading: () => const _StatsText(label: '…', sub: 'Calculating'),
              error: (_, __) =>
                  const _StatsText(label: '0.0%', sub: 'Ankara explored'),
              data: (stats) => _StatsText(
                label: '${stats.explorationPercent.toStringAsFixed(1)}%',
                sub:
                    '${stats.exploredCells} cells · ${stats.distanceFormatted}',
              ),
            ),
          ),

          // ── Session status badge ────────────────────────────────────
          _SessionBadge(state: sessionState),
        ],
      ),
    );
  }
}

class _StatsText extends StatelessWidget {
  final String label;
  final String sub;
  const _StatsText({required this.label, required this.sub});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(label,
            style: const TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.w800,
                color: AppColors.primary,
                height: 1)),
        Text(sub,
            style: const TextStyle(
                fontSize: 11, color: AppColors.textSecondary)),
      ],
    );
  }
}

class _SessionBadge extends StatelessWidget {
  final SessionState state;
  const _SessionBadge({required this.state});

  @override
  Widget build(BuildContext context) {
    if (state == SessionState.idle) return const SizedBox.shrink();

    final isActive = state == SessionState.active;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: (isActive ? AppColors.primary : AppColors.accent)
            .withAlpha(51),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 7,
            height: 7,
            decoration: BoxDecoration(
              color: isActive ? AppColors.primary : AppColors.accent,
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 6),
          Text(
            isActive ? 'Active' : 'Paused',
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w600,
              color: isActive ? AppColors.primary : AppColors.accent,
            ),
          ),
        ],
      ),
    );
  }
}
