// lib/ui/widgets/session_controls.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../core/constants.dart';
import '../../providers/session_provider.dart';
import '../../services/session_manager.dart' show SessionState;
import '../../services/location_service.dart';

class SessionControls extends ConsumerWidget {
  final SessionState sessionState;
  const SessionControls({super.key, required this.sessionState});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return switch (sessionState) {
      SessionState.idle => _IdleControls(),
      SessionState.active => _ActiveControls(),
      SessionState.paused => _PausedControls(),
    };
  }
}

// ── IDLE: single "Start Exploring" button ─────────────────────────────────

class _IdleControls extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isLoading = ref.watch(sessionProvider).isLoading;

    return SizedBox(
      width: double.infinity,
      child: ElevatedButton.icon(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.primary,
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(vertical: 18),
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16)),
        ),
        icon: isLoading
            ? const SizedBox(
                width: 18,
                height: 18,
                child: CircularProgressIndicator(
                    color: Colors.white, strokeWidth: 2))
            : const Icon(Icons.play_arrow_rounded, size: 26),
        label: Text(isLoading ? 'Starting…' : 'Start Exploring',
            style: const TextStyle(
                fontSize: 16, fontWeight: FontWeight.w700)),
        onPressed: isLoading
            ? null
            : () async {
                final locationService = ref.read(locationServiceProvider);
                final granted = await locationService.ensurePermission();
                if (!granted) {
                  if (context.mounted) {
                    _showPermissionDialog(context, locationService);
                  }
                  return;
                }
                ref.read(sessionProvider.notifier).startSession();
              },
      ),
    ).animate().fadeIn(duration: 250.ms).slideY(begin: 0.15, end: 0);
  }

  void _showPermissionDialog(
      BuildContext context, LocationService locationService) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Location Required'),
        content: const Text(
          'CityGrid needs your location to track which areas you explore. '
          'Please enable location access in Settings.',
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel')),
          TextButton(
              onPressed: () {
                Navigator.pop(context);
                locationService.openSettings();
              },
              child: const Text('Open Settings')),
        ],
      ),
    );
  }
}

// ── ACTIVE: Pause + Stop ──────────────────────────────────────────────────

class _ActiveControls extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Row(
      children: [
        // Pause button
        Expanded(
          child: OutlinedButton.icon(
            style: OutlinedButton.styleFrom(
              foregroundColor: AppColors.textPrimary,
              side: const BorderSide(color: AppColors.textSecondary),
              padding: const EdgeInsets.symmetric(vertical: 16),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16)),
            ),
            icon: const Icon(Icons.pause_rounded),
            label: const Text('Pause',
                style: TextStyle(fontWeight: FontWeight.w600)),
            onPressed: () =>
                ref.read(sessionProvider.notifier).pauseSession(),
          ),
        ),
        const SizedBox(width: 12),
        // Stop button
        Expanded(
          flex: 2,
          child: ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.danger,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(vertical: 16),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16)),
            ),
            icon: const Icon(Icons.stop_rounded),
            label: const Text('Stop Session',
                style: TextStyle(fontWeight: FontWeight.w700)),
            onPressed: () => _stopAndShowSummary(context, ref),
          ),
        ),
      ],
    ).animate().fadeIn(duration: 250.ms);
  }

  Future<void> _stopAndShowSummary(
      BuildContext context, WidgetRef ref) async {
    final summary =
        await ref.read(sessionProvider.notifier).stopSession();
    if (summary == null || !context.mounted) return;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (_) => _SessionSummarySheet(summary: summary),
    );
  }
}

// ── PAUSED: Resume + Stop ─────────────────────────────────────────────────

class _PausedControls extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Row(
      children: [
        // Resume button
        Expanded(
          flex: 2,
          child: ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primary,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(vertical: 16),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16)),
            ),
            icon: const Icon(Icons.play_arrow_rounded),
            label: const Text('Resume',
                style: TextStyle(fontWeight: FontWeight.w700)),
            onPressed: () =>
                ref.read(sessionProvider.notifier).resumeSession(),
          ),
        ),
        const SizedBox(width: 12),
        // Stop button
        Expanded(
          child: OutlinedButton.icon(
            style: OutlinedButton.styleFrom(
              foregroundColor: AppColors.danger,
              side: const BorderSide(color: AppColors.danger),
              padding: const EdgeInsets.symmetric(vertical: 16),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16)),
            ),
            icon: const Icon(Icons.stop_rounded),
            label: const Text('Stop',
                style: TextStyle(fontWeight: FontWeight.w600)),
            onPressed: () async {
              final summary =
                  await ref.read(sessionProvider.notifier).stopSession();
              if (summary == null || !context.mounted) return;
              showModalBottomSheet(
                context: context,
                isScrollControlled: true,
                shape: const RoundedRectangleBorder(
                    borderRadius:
                        BorderRadius.vertical(top: Radius.circular(24))),
                builder: (_) => _SessionSummarySheet(summary: summary),
              );
            },
          ),
        ),
      ],
    ).animate().fadeIn(duration: 250.ms);
  }
}

// ── Session summary bottom sheet ──────────────────────────────────────────

class _SessionSummarySheet extends StatelessWidget {
  final dynamic summary; // SessionSummary
  const _SessionSummarySheet({required this.summary});

  @override
  Widget build(BuildContext context) {
    final h = summary.activeDuration.inHours;
    final m = summary.activeDuration.inMinutes % 60;
    final s = summary.activeDuration.inSeconds % 60;
    final durationStr =
        h > 0 ? '${h}h ${m}m' : m > 0 ? '${m}m ${s}s' : '${s}s';

    final distKm = summary.distanceMeters / 1000.0;
    final distStr = distKm >= 1
        ? '${distKm.toStringAsFixed(2)} km'
        : '${summary.distanceMeters.round()} m';

    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Handle
            Container(
              width: 40,
              height: 4,
              margin: const EdgeInsets.only(bottom: 20),
              decoration: BoxDecoration(
                color: AppColors.textSecondary.withAlpha(77),
                borderRadius: BorderRadius.circular(2),
              ),
            ),

            const Text('Session Complete! 🎉',
                style: TextStyle(
                    fontSize: 20, fontWeight: FontWeight.w700)),
            const SizedBox(height: 24),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _SummaryStat(
                    label: 'Duration', value: durationStr, icon: '⏱'),
                _SummaryStat(
                    label: 'Distance', value: distStr, icon: '🚶'),
                _SummaryStat(
                    label: 'Explored',
                    value: '${summary.cellsExplored}',
                    icon: '🗺'),
              ],
            ),

            if ((summary.newAchievements as List).isNotEmpty) ...[
              const SizedBox(height: 20),
              Text('Achievements unlocked! 🏆',
                  style: TextStyle(
                      color: AppColors.accent,
                      fontWeight: FontWeight.w600)),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                children: [
                  for (final id in summary.newAchievements as List<String>)
                    Chip(
                      label: Text(id.replaceAll('_', ' ')),
                      backgroundColor: AppColors.accent.withAlpha(51),
                    ),
                ],
              ),
            ],

            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Done'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SummaryStat extends StatelessWidget {
  final String label;
  final String value;
  final String icon;
  const _SummaryStat(
      {required this.label, required this.value, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(icon, style: const TextStyle(fontSize: 28)),
        const SizedBox(height: 4),
        Text(value,
            style: const TextStyle(
                fontSize: 18, fontWeight: FontWeight.w700)),
        Text(label,
            style: const TextStyle(
                fontSize: 12, color: AppColors.textSecondary)),
      ],
    );
  }
}
