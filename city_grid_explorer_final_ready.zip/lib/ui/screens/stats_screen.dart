// lib/ui/screens/stats_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/constants.dart';
import '../../core/utils/date_utils.dart';
import '../../data/database/app_database.dart';
import '../../providers/stats_provider.dart';
import '../../providers/session_provider.dart';

class StatsScreen extends ConsumerWidget {
  const StatsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final statsAsync = ref.watch(statsProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Statistics')),
      body: statsAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('Error: $e')),
        data: (stats) => ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // ── Progress ring ──────────────────────────────────────
            _ProgressCard(stats: stats),
            const SizedBox(height: 16),

            // ── Key metrics ────────────────────────────────────────
            _MetricsGrid(stats: stats),
            const SizedBox(height: 24),

            // ── Clear history ──────────────────────────────────────
            OutlinedButton.icon(
              style: OutlinedButton.styleFrom(
                foregroundColor: AppColors.danger,
                side: const BorderSide(color: AppColors.danger),
              ),
              icon: const Icon(Icons.delete_outline),
              label: const Text('Clear All History'),
              onPressed: () => _confirmClear(context, ref),
            ),
          ],
        ),
      ),
    );
  }

  void _confirmClear(BuildContext context, WidgetRef ref) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Clear History'),
        content: const Text(
          'This will erase all explored cells, sessions, and achievements. '
          'This cannot be undone.',
        ),
        actions: [
          TextButton(
            child: const Text('Cancel'),
            onPressed: () => Navigator.pop(ctx),
          ),
          TextButton(
            style: TextButton.styleFrom(foregroundColor: AppColors.danger),
            child: const Text('Clear Everything'),
            onPressed: () async {
              Navigator.pop(ctx);
              await AppDatabase.instance.clearHistory();
              ref.invalidate(statsProvider);
            },
          ),
        ],
      ),
    );
  }
}

class _ProgressCard extends StatelessWidget {
  final ExplorationStats stats;
  const _ProgressCard({required this.stats});

  @override
  Widget build(BuildContext context) {
    final pct = stats.explorationPercent;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            Text(
              '${pct.toStringAsFixed(1)}%',
              style: Theme.of(context).textTheme.displaySmall?.copyWith(
                    color: AppColors.primary,
                    fontWeight: FontWeight.w700,
                  ),
            ),
            const SizedBox(height: 8),
            Text('of Ankara explored',
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: AppColors.textSecondary,
                    )),
            const SizedBox(height: 16),
            LinearProgressIndicator(
              value: pct / 100,
              backgroundColor: AppColors.surface,
              color: AppColors.primary,
              minHeight: 8,
            ),
            const SizedBox(height: 8),
            Text(
              '${stats.exploredCells} explored · ${stats.transitCells} transit',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: AppColors.textSecondary,
                  ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MetricsGrid extends StatelessWidget {
  final ExplorationStats stats;
  const _MetricsGrid({required this.stats});

  @override
  Widget build(BuildContext context) {
    return GridView.count(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisCount: 2,
      mainAxisSpacing: 12,
      crossAxisSpacing: 12,
      childAspectRatio: 1.6,
      children: [
        _MetricCard(
          label: 'Distance',
          value: stats.distanceFormatted,
          icon: Icons.directions_walk,
        ),
        _MetricCard(
          label: 'Sessions',
          value: '${stats.completedSessions}',
          icon: Icons.play_circle_outline,
        ),
        _MetricCard(
          label: 'Explored',
          value: '${stats.exploredCells}',
          icon: Icons.grid_on,
        ),
        _MetricCard(
          label: 'Transit',
          value: '${stats.transitCells}',
          icon: Icons.directions_bus_outlined,
        ),
      ],
    );
  }
}

class _MetricCard extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  const _MetricCard(
      {required this.label, required this.value, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: AppColors.primary, size: 20),
            const SizedBox(height: 6),
            Text(value,
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.w700,
                    )),
            Text(label,
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: AppColors.textSecondary,
                    )),
          ],
        ),
      ),
    );
  }
}
