// lib/ui/screens/map_screen.dart
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:mapbox_maps_flutter/mapbox_maps_flutter.dart';
import '../../core/constants.dart';
import '../../core/utils/geo_math.dart';
import '../../core/utils/date_utils.dart';
import '../../data/models/grid_cell.dart';
import '../../providers/session_provider.dart';
import '../../providers/grid_provider.dart';
import '../../providers/stats_provider.dart' show settingsProvider, AppSettings;
import '../../services/location_service.dart';
import '../../services/session_manager.dart' show SessionState;
import '../widgets/session_controls.dart';
import '../widgets/stats_bar.dart';

class MapScreen extends ConsumerStatefulWidget {
  const MapScreen({super.key});

  @override
  ConsumerState<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends ConsumerState<MapScreen> {
  MapboxMap? _mapboxMap;
  Timer? _debounceTimer;
  bool _sourceReady = false;

  static const _gridSourceId = 'grid-source';
  static const _gridFillLayerId = 'grid-fill';
  static const _gridLineLayerId = 'grid-lines';

  // ── Lifecycle ──────────────────────────────────────────────────────

  @override
  void dispose() {
    _debounceTimer?.cancel();
    super.dispose();
  }

  // ── Map callbacks ──────────────────────────────────────────────────

  void _onMapCreated(MapboxMap mapboxMap) {
    _mapboxMap = mapboxMap;
    _setupMapLayers();

    // Wire up grid engine to update map incrementally during session
    final engine = ref.read(gridEngineProvider);
    engine.onCellUpdated = (cell) {
      ref.read(gridProvider.notifier).updateSingleCell(cell);
    };
  }

  Future<void> _setupMapLayers() async {
    if (_mapboxMap == null) return;

    // Add GeoJSON source (empty FeatureCollection to start)
    await _mapboxMap!.style.addSource(GeoJsonSource(
      id: _gridSourceId,
      data: '{"type":"FeatureCollection","features":[]}',
    ));

    // Fill layer for explored/transit cells
    await _mapboxMap!.style.addLayer(FillLayer(
      id: _gridFillLayerId,
      sourceId: _gridSourceId,
      fillOpacity: AppConstants.cellFillOpacity,
      fillColor: 0xFF00BFA5, // Default; overridden by GeoJSON data-driven
    ));

    // Grid lines layer — visible only at zoom ≥ 15
    await _mapboxMap!.style.addLayer(LineLayer(
      id: _gridLineLayerId,
      sourceId: _gridSourceId,
      lineColor: AppColors.gridLine.value,
      lineWidth: 0.5,
      minZoom: AppConstants.gridLineMinZoom,
    ));

    _sourceReady = true;

    // Load cells for the initial viewport
    _loadVisibleCells();
  }

  void _onCameraChanged(CameraChangedEventData event) {
    // Debounce: wait 200ms after the last camera event before loading cells
    _debounceTimer?.cancel();
    _debounceTimer = Timer(
      const Duration(milliseconds: AppConstants.mapDebounceMs),
      _loadVisibleCells,
    );
  }

  Future<void> _loadVisibleCells() async {
    if (_mapboxMap == null || !_sourceReady) return;

    final bounds = await _mapboxMap!.coordinateBoundsForCamera(
      await _mapboxMap!.cameraState,
    );

    final gridBounds = GeoMath.viewportGridBounds(
      southLat: bounds.southwest.coordinates.lat.toDouble(),
      westLng: bounds.southwest.coordinates.lng.toDouble(),
      northLat: bounds.northeast.coordinates.lat.toDouble(),
      eastLng: bounds.northeast.coordinates.lng.toDouble(),
    );

    final repo = ref.read(gridRepositoryProvider);
    final cells = await repo.getCellsInBounds(
      minX: gridBounds.minX,
      minY: gridBounds.minY,
      maxX: gridBounds.maxX,
      maxY: gridBounds.maxY,
    );

    ref.read(gridProvider.notifier).updateCells(cells);
    _updateGeoJsonSource(ref.read(gridProvider).visibleCells.values.toList());
  }

  // ── GeoJSON update (PDF §6.2) ──────────────────────────────────────

  Future<void> _updateGeoJsonSource(List<GridCell> cells) async {
    if (_mapboxMap == null || !_sourceReady) return;

    final settings = ref.read(settingsProvider);

    final features = cells
        .where((c) => c.state != CellState.unexplored)
        .map((cell) {
      final corners = GeoMath.cellCorners(cell.gridX, cell.gridY);
      final freshness =
          AppDateUtils.freshness(cell.lastVisited, gradientDays: settings.gradientDays);

      // Pick base color based on state
      String fillColor;
      if (cell.state == CellState.explored) {
        fillColor = _lerpColor(
          AppColors.exploredFaded,
          AppColors.exploredVivid,
          freshness,
        );
      } else {
        fillColor = _lerpColor(
          AppColors.transitFaded,
          AppColors.transitVivid,
          freshness,
        );
      }

      return {
        'type': 'Feature',
        'properties': {
          'state': cell.state.index,
          'freshness': freshness,
          'cell_id': cell.cellId,
          'fill_color': fillColor,
        },
        'geometry': {
          'type': 'Polygon',
          'coordinates': [
            [
              [corners[0].$2, corners[0].$1], // [lng, lat] — GeoJSON order
              [corners[1].$2, corners[1].$1],
              [corners[2].$2, corners[2].$1],
              [corners[3].$2, corners[3].$1],
              [corners[0].$2, corners[0].$1], // close polygon
            ]
          ],
        },
      };
    }).toList();

    final geojson = jsonEncode({
      'type': 'FeatureCollection',
      'features': features,
    });

    await _mapboxMap!.style.setStyleSourceProperty(
      _gridSourceId,
      'data',
      geojson,
    );
  }

  /// Linear interpolate between two colors at ratio t (0.0 – 1.0).
  String _lerpColor(Color from, Color to, double t) {
    final r = (from.red + (to.red - from.red) * t).round().clamp(0, 255);
    final g = (from.green + (to.green - from.green) * t).round().clamp(0, 255);
    final b = (from.blue + (to.blue - from.blue) * t).round().clamp(0, 255);
    return '#${r.toRadixString(16).padLeft(2, '0')}${g.toRadixString(16).padLeft(2, '0')}${b.toRadixString(16).padLeft(2, '0')}';
  }

  // ── Re-center (BUG 4 FIX) ──────────────────────────────────────────

  Future<void> _recenterCamera() async {
    // BUG 4 FIX: We get the ACTUAL current GPS position, never a hardcoded coord.
    final locationService = ref.read(locationServiceProvider);
    final pos = await locationService.getCurrentPosition();

    if (pos == null) {
      // No GPS fix — fall back to city center from settings
      final settings = ref.read(settingsProvider);
      _flyTo(settings.cityLat, settings.cityLng);
      return;
    }

    _flyTo(pos.lat, pos.lng);
  }

  void _flyTo(double lat, double lng) {
    _mapboxMap?.flyTo(
      CameraOptions(
        center: Point(coordinates: Position(lng, lat)),
        zoom: 15.5,
      ),
      MapAnimationOptions(duration: 800, startDelay: 0),
    );
  }

  // ── Cell long-press override (PDF §4.6) ────────────────────────────

  void _onMapLongPress(MapContentGestureContext context) async {
    final lat = context.point.coordinates.lat.toDouble();
    final lng = context.point.coordinates.lng.toDouble();
    final (gridX, gridY) = GeoMath.latLngToGrid(lat, lng);
    final cellId = GeoMath.makeCellId(gridX, gridY);

    final repo = ref.read(gridRepositoryProvider);
    final cell = await repo.getCell(cellId);
    if (!mounted) return;

    showModalBottomSheet(
      context: context as dynamic,
      builder: (_) => _CellOverrideSheet(
        cellId: cellId,
        currentState: cell?.state ?? CellState.unexplored,
        onStateSelected: (newState) async {
          await repo.updateCellState(cellId, newState);
          _loadVisibleCells();
        },
      ),
    );
  }

  // ── Build ──────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    // Rebuild GeoJSON when grid state changes
    ref.listen(gridProvider, (prev, next) {
      if (next.needsRebuild) {
        _updateGeoJsonSource(next.visibleCells.values.toList());
        ref.read(gridProvider.notifier).markRebuilt();
      }
    });

    final sessionState =
        ref.watch(sessionProvider).sessionState;

    final settings = ref.watch(settingsProvider);

    return Scaffold(
      body: Stack(
        children: [
          // ── Map ──────────────────────────────────────────────────
          MapWidget(
            key: const ValueKey('mapbox'),
            onMapCreated: _onMapCreated,
            onCameraChangeListener: _onCameraChanged,
            onLongTapListener: _onMapLongPress,
            cameraOptions: CameraOptions(
              center: Point(
                coordinates: Position(settings.cityLng, settings.cityLat),
              ),
              zoom: 13.0,
            ),
          ),

          // ── Stats bar ────────────────────────────────────────────
          const Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: SafeArea(child: StatsBar()),
          ),

          // ── Session controls ─────────────────────────────────────
          Positioned(
            bottom: 24,
            left: 16,
            right: 16,
            child: SessionControls(sessionState: sessionState),
          ),

          // ── Re-center button ─────────────────────────────────────
          Positioned(
            bottom: 120,
            right: 16,
            child: FloatingActionButton.small(
              heroTag: 'recenter',
              onPressed: _recenterCamera,
              backgroundColor: AppColors.surface,
              foregroundColor: AppColors.textPrimary,
              tooltip: 'Center on my location',
              child: const Icon(Icons.my_location),
            ),
          ),
        ],
      ),
    );
  }
}

// ── Cell Override Bottom Sheet ─────────────────────────────────────────────

class _CellOverrideSheet extends StatelessWidget {
  final String cellId;
  final CellState currentState;
  final void Function(CellState) onStateSelected;

  const _CellOverrideSheet({
    required this.cellId,
    required this.currentState,
    required this.onStateSelected,
  });

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Cell $cellId',
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: AppColors.textSecondary,
                    )),
            Text('Currently: ${currentState.label}',
                style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 16),
            for (final state in CellState.values)
              if (state != currentState)
                ListTile(
                  title: Text('Mark as ${state.label}'),
                  onTap: () {
                    Navigator.pop(context);
                    onStateSelected(state);
                  },
                ),
          ],
        ),
      ),
    );
  }
}
