// lib/ui/screens/settings_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/constants.dart';
import '../../providers/stats_provider.dart';

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final settings = ref.watch(settingsProvider);
    final notifier = ref.read(settingsProvider.notifier);

    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        children: [
          // ── Map ──────────────────────────────────────────────────
          _SectionHeader('Map'),
          SwitchListTile(
            title: const Text('Show Grid Lines'),
            subtitle: const Text('Visible at zoom 15+'),
            value: settings.showGridLines,
            onChanged: (_) => notifier.toggleGridLines(),
          ),
          ListTile(
            title: const Text('Freshness Gradient'),
            subtitle: Text('${settings.gradientDays} days'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => _showGradientDaysPicker(context, ref),
          ),

          // ── Units ─────────────────────────────────────────────────
          _SectionHeader('Units'),
          RadioListTile<String>(
            title: const Text('Metric (km, m)'),
            value: 'metric',
            groupValue: settings.unitSystem,
            onChanged: (v) => notifier.setUnitSystem(v!),
          ),
          RadioListTile<String>(
            title: const Text('Imperial (mi, ft)'),
            value: 'imperial',
            groupValue: settings.unitSystem,
            onChanged: (v) => notifier.setUnitSystem(v!),
          ),

          // ── City ─────────────────────────────────────────────────
          _SectionHeader('City'),
          ListTile(
            title: const Text('Current City'),
            subtitle: Text(settings.cityName),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => _showCityPicker(context, ref),
          ),

          // ── Privacy ───────────────────────────────────────────────
          _SectionHeader('Privacy'),
          ListTile(
            title: const Text('Privacy Policy'),
            trailing: const Icon(Icons.open_in_new),
            onTap: () {
              // Open privacy policy URL
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                    content: Text(
                        'Visit your privacy policy URL here')),
              );
            },
          ),

          // ── About ─────────────────────────────────────────────────
          _SectionHeader('About'),
          const ListTile(
            title: Text('Version'),
            trailing: Text('1.0.0', style: TextStyle(color: AppColors.textSecondary)),
          ),
          const ListTile(
            title: Text('Data Storage'),
            subtitle: Text(
              'All data stays on your device.\nNothing is uploaded to servers.',
            ),
          ),
          const SizedBox(height: 32),
        ],
      ),
    );
  }

  void _showGradientDaysPicker(BuildContext context, WidgetRef ref) {
    final current = ref.read(settingsProvider).gradientDays;
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Freshness Gradient'),
        content: StatefulBuilder(
          builder: (context, setState) {
            var days = current;
            return Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text('$days days'),
                Slider(
                  value: days.toDouble(),
                  min: 7,
                  max: 90,
                  divisions: 11,
                  onChanged: (v) => setState(() => days = v.round()),
                ),
              ],
            );
          },
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  void _showCityPicker(BuildContext context, WidgetRef ref) {
    showDialog(
      context: context,
      builder: (ctx) => CitySearchDialog(
        onCitySelected: (name, lat, lng) {
          ref.read(settingsProvider.notifier).setCity(
                name: name,
                lat: lat,
                lng: lng,
              );
          Navigator.pop(ctx);
        },
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final String title;
  const _SectionHeader(this.title);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 24, 16, 8),
      child: Text(
        title.toUpperCase(),
        style: Theme.of(context).textTheme.labelSmall?.copyWith(
              color: AppColors.primary,
              letterSpacing: 1.2,
            ),
      ),
    );
  }
}

class CitySearchDialog extends StatelessWidget {
  final void Function(String name, double lat, double lng) onCitySelected;
  const CitySearchDialog({super.key, required this.onCitySelected});

  // Preset cities
  static const List<_CityEntry> _cities = [
    _CityEntry('Ankara', 39.9334, 32.8597),
    _CityEntry('Istanbul', 41.0082, 28.9784),
    _CityEntry('Izmir', 38.4192, 27.1287),
    _CityEntry('Bursa', 40.1826, 29.0665),
    _CityEntry('Antalya', 36.8969, 30.7133),
    _CityEntry('Adana', 37.0000, 35.3213),
    _CityEntry('Konya', 37.8714, 32.4846),
  ];

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Select City'),
      content: SizedBox(
        width: double.maxFinite,
        child: ListView.builder(
          shrinkWrap: true,
          itemCount: _cities.length,
          itemBuilder: (ctx, i) {
            final city = _cities[i];
            return ListTile(
              title: Text(city.name),
              onTap: () => onCitySelected(city.name, city.lat, city.lng),
            );
          },
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel'),
        ),
      ],
    );
  }
}

class _CityEntry {
  final String name;
  final double lat;
  final double lng;
  const _CityEntry(this.name, this.lat, this.lng);
}
