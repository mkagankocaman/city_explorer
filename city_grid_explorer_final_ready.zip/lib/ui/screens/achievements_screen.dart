// lib/ui/screens/achievements_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../core/constants.dart';
import '../../data/models/achievement.dart';
import '../../data/repositories/achievement_repository.dart';
import '../../providers/session_provider.dart';

final _achievementsProvider = FutureProvider<List<Achievement>>((ref) async {
  // Refresh when session completes
  ref.watch(sessionProvider);
  final repo = AchievementRepository(ref.read(appDatabaseProvider));
  return repo.getAll();
});

class AchievementsScreen extends ConsumerWidget {
  const AchievementsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final achievementsAsync = ref.watch(_achievementsProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Achievements')),
      body: achievementsAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('Error: $e')),
        data: (achievements) {
          final defs = AchievementDefs.all;
          final byId = {
            for (final a in achievements) a.achievementId: a,
          };
          final unlockedCount =
              achievements.where((a) => a.isUnlocked).length;

          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(16),
                child: Text(
                  '$unlockedCount / ${defs.length} unlocked',
                  style: Theme.of(context).textTheme.titleSmall?.copyWith(
                        color: AppColors.textSecondary,
                      ),
                ),
              ),
              Expanded(
                child: ListView.separated(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  itemCount: defs.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 8),
                  itemBuilder: (context, i) {
                    final def = defs[i];
                    final achievement = byId[def['id']];
                    final isUnlocked = achievement?.isUnlocked ?? false;

                    return AchievementCard(
                      def: def,
                      achievement: achievement,
                      isUnlocked: isUnlocked,
                    ).animate(delay: Duration(milliseconds: i * 50)).fadeIn();
                  },
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class AchievementCard extends StatelessWidget {
  final Map<String, dynamic> def;
  final Achievement? achievement;
  final bool isUnlocked;

  const AchievementCard({
    super.key,
    required this.def,
    required this.achievement,
    required this.isUnlocked,
  });

  @override
  Widget build(BuildContext context) {
    final progress = achievement?.progress ?? 0.0;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            // ── Emoji badge ────────────────────────────────────────
            Container(
              width: 52,
              height: 52,
              decoration: BoxDecoration(
                color: isUnlocked
                    ? AppColors.primary.withAlpha(51)
                    : AppColors.surface,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Center(
                child: Text(
                  def['emoji'] as String,
                  style: TextStyle(
                    fontSize: 26,
                    color: isUnlocked ? null : const Color(0xFF666666),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 16),

            // ── Text + progress ────────────────────────────────────
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    def['name'] as String,
                    style: Theme.of(context).textTheme.titleSmall?.copyWith(
                          color: isUnlocked
                              ? AppColors.textPrimary
                              : AppColors.textSecondary,
                        ),
                  ),
                  Text(
                    def['description'] as String,
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: AppColors.textSecondary,
                        ),
                  ),
                  if (!isUnlocked && progress > 0) ...[
                    const SizedBox(height: 6),
                    LinearProgressIndicator(
                      value: progress,
                      backgroundColor: AppColors.surface,
                      color: AppColors.accent,
                      minHeight: 4,
                    ),
                    Text(
                      '${(progress * 100).round()}%',
                      style: Theme.of(context).textTheme.labelSmall?.copyWith(
                            color: AppColors.textSecondary,
                          ),
                    ),
                  ],
                ],
              ),
            ),

            // ── Lock / checkmark ───────────────────────────────────
            Icon(
              isUnlocked ? Icons.check_circle : Icons.lock_outline,
              color: isUnlocked ? AppColors.success : AppColors.textSecondary,
            ),
          ],
        ),
      ),
    );
  }
}
