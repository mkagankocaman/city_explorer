// lib/providers/grid_provider.dart
//
// Re-exports GridState, GridNotifier, and gridProvider from stats_provider.dart.
// This keeps the import paths in map_screen.dart clean and matches the folder
// structure specified in PDF §2.3.
export 'stats_provider.dart'
    show GridState, GridNotifier, gridProvider;
