// lib/providers/stats_provider.dart
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../data/models/grid_cell.dart';
import '../data/database/app_database.dart';
import 'session_provider.dart';

class ExplorationStats {
  final int exploredCells;
  final int transitCells;
  final double totalDistanceMeters;
  final int completedSessions;
  final double cityRadiusKm;

  const ExplorationStats({
    this.exploredCells = 0,
    this.transitCells = 0,
    this.totalDistanceMeters = 0.0,
    this.completedSessions = 0,
    this.cityRadiusKm = 15.0,
  });

  /// Total cells within the city radius circle.
  /// π × r² in cell units. At 15 km radius with 150 m cells:
  /// r_cells = 15000 / 150 = 100 → π × 100² ≈ 31,416 cells
  int get totalCityCells {
    final rCells = (cityRadiusKm * 1000) / 150;
    return (3.14159265 * rCells * rCells).round();
  }

  double get explorationPercent =>
      totalCityCells > 0 ? (exploredCells / totalCityCells * 100) : 0.0;

  String get distanceFormatted {
    if (totalDistanceMeters >= 1000) {
      return '${(totalDistanceMeters / 1000).toStringAsFixed(1)} km';
    }
    return '${totalDistanceMeters.round()} m';
  }
}

final statsProvider = FutureProvider<ExplorationStats>((ref) async {
  final gridRepo = ref.read(gridRepositoryProvider);
  final sessionRepo = ref.read(sessionRepositoryProvider);
  // Refresh when session state changes
  ref.watch(sessionProvider);

  final explored = await gridRepo.countByState(CellState.explored);
  final transit = await gridRepo.countByState(CellState.transit);
  final distanceM = await sessionRepo.totalDistanceMeters();
  final sessions = await sessionRepo.completedSessionCount();

  return ExplorationStats(
    exploredCells: explored,
    transitCells: transit,
    totalDistanceMeters: distanceM,
    completedSessions: sessions,
  );
});

// ─────────────────────────────────────────────────────────────────────────────

// lib/providers/settings_provider.dart
class AppSettings {
  final String cityName;
  final double cityLat;
  final double cityLng;
  final double cityRadiusKm;
  final bool showGridLines;
  final int gradientDays;
  final String unitSystem; // 'metric' | 'imperial'

  const AppSettings({
    this.cityName = 'Ankara',
    this.cityLat = 39.9334,
    this.cityLng = 32.8597,
    this.cityRadiusKm = 15.0,
    this.showGridLines = true,
    this.gradientDays = 30,
    this.unitSystem = 'metric',
  });

  AppSettings copyWith({
    String? cityName,
    double? cityLat,
    double? cityLng,
    double? cityRadiusKm,
    bool? showGridLines,
    int? gradientDays,
    String? unitSystem,
  }) =>
      AppSettings(
        cityName: cityName ?? this.cityName,
        cityLat: cityLat ?? this.cityLat,
        cityLng: cityLng ?? this.cityLng,
        cityRadiusKm: cityRadiusKm ?? this.cityRadiusKm,
        showGridLines: showGridLines ?? this.showGridLines,
        gradientDays: gradientDays ?? this.gradientDays,
        unitSystem: unitSystem ?? this.unitSystem,
      );
}

class SettingsNotifier extends StateNotifier<AppSettings> {
  SettingsNotifier() : super(const AppSettings());

  void toggleGridLines() =>
      state = state.copyWith(showGridLines: !state.showGridLines);

  void setGradientDays(int days) =>
      state = state.copyWith(gradientDays: days);

  void setUnitSystem(String system) =>
      state = state.copyWith(unitSystem: system);

  void setCity({
    required String name,
    required double lat,
    required double lng,
    double radiusKm = 15.0,
  }) =>
      state = state.copyWith(
        cityName: name,
        cityLat: lat,
        cityLng: lng,
        cityRadiusKm: radiusKm,
      );
}

final settingsProvider =
    StateNotifierProvider<SettingsNotifier, AppSettings>((ref) {
  return SettingsNotifier();
});

// ─────────────────────────────────────────────────────────────────────────────

// lib/providers/grid_provider.dart
import '../data/models/grid_cell.dart';

class GridState {
  /// Currently visible cells (by cellId).
  final Map<String, GridCell> visibleCells;
  final bool needsRebuild;

  const GridState({
    this.visibleCells = const {},
    this.needsRebuild = false,
  });

  GridState copyWith({
    Map<String, GridCell>? visibleCells,
    bool? needsRebuild,
  }) =>
      GridState(
        visibleCells: visibleCells ?? this.visibleCells,
        needsRebuild: needsRebuild ?? this.needsRebuild,
      );
}

class GridNotifier extends StateNotifier<GridState> {
  GridNotifier() : super(const GridState());

  void updateCells(List<GridCell> cells) {
    final map = Map<String, GridCell>.from(state.visibleCells);
    for (final cell in cells) {
      map[cell.cellId] = cell;
    }
    state = state.copyWith(visibleCells: map, needsRebuild: true);
  }

  void updateSingleCell(GridCell cell) {
    final map = Map<String, GridCell>.from(state.visibleCells);
    map[cell.cellId] = cell;
    state = state.copyWith(visibleCells: map, needsRebuild: true);
  }

  void markRebuilt() {
    state = state.copyWith(needsRebuild: false);
  }
}

final gridProvider =
    StateNotifierProvider<GridNotifier, GridState>((ref) {
  return GridNotifier();
});

// ─────────────────────────────────────────────────────────────────────────────

// lib/providers/location_provider.dart

class LocationState {
  final double? currentLat;
  final double? currentLng;
  final bool hasPermission;

  const LocationState({
    this.currentLat,
    this.currentLng,
    this.hasPermission = false,
  });

  bool get hasPosition => currentLat != null && currentLng != null;
}

class LocationNotifier extends StateNotifier<LocationState> {
  LocationNotifier() : super(const LocationState());

  void updatePosition(double lat, double lng) {
    state = LocationState(
        currentLat: lat, currentLng: lng, hasPermission: state.hasPermission);
  }

  void setPermission(bool granted) {
    state = LocationState(
        currentLat: state.currentLat,
        currentLng: state.currentLng,
        hasPermission: granted);
  }
}

final locationStateProvider =
    StateNotifierProvider<LocationNotifier, LocationState>((ref) {
  return LocationNotifier();
});
