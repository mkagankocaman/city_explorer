// lib/providers/session_provider.dart
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../data/database/app_database.dart';
import '../data/repositories/session_repository.dart';
import '../data/repositories/grid_repository.dart';
import '../data/repositories/achievement_repository.dart';
import '../data/repositories/location_point_repository.dart';
import '../services/location_service.dart';
import '../services/grid_engine.dart';
import '../services/classifier_engine.dart';
import '../services/session_manager.dart';
import '../services/achievement_service.dart';

// ── Singletons ─────────────────────────────────────────────────────────────

final appDatabaseProvider = Provider<AppDatabase>((ref) {
  return AppDatabase.instance;
});

// ── Repositories ───────────────────────────────────────────────────────────

final gridRepositoryProvider = Provider<GridRepository>((ref) {
  return GridRepository(ref.read(appDatabaseProvider));
});

final sessionRepositoryProvider = Provider<SessionRepository>((ref) {
  return SessionRepository(ref.read(appDatabaseProvider));
});

final achievementRepositoryProvider = Provider<AchievementRepository>((ref) {
  return AchievementRepository(ref.read(appDatabaseProvider));
});

final locationPointRepositoryProvider =
    Provider<LocationPointRepository>((ref) {
  return LocationPointRepository(ref.read(appDatabaseProvider));
});

// ── Services ───────────────────────────────────────────────────────────────

final locationServiceProvider = Provider<LocationService>((ref) {
  final svc = LocationService();
  ref.onDispose(svc.dispose);
  return svc;
});

final classifierProvider = Provider<ClassifierEngine>((ref) {
  return ClassifierEngine.instance;
});

final gridEngineProvider = Provider<GridEngine>((ref) {
  return GridEngine(
    ref.read(gridRepositoryProvider),
    ref.read(classifierProvider),
  );
});

final achievementServiceProvider = Provider<AchievementService>((ref) {
  return AchievementService(
    achievementRepo: ref.read(achievementRepositoryProvider),
    gridRepo: ref.read(gridRepositoryProvider),
    sessionRepo: ref.read(sessionRepositoryProvider),
  );
});

// ── Session state notifier ─────────────────────────────────────────────────

class SessionNotifier extends StateNotifier<SessionManagerState> {
  final SessionManager _manager;

  SessionNotifier(this._manager) : super(const SessionManagerState()) {
    _manager.onStateChanged = (s) {
      state = state.copyWith(sessionState: s);
    };
    _manager.onSessionCompleted = (summary) {
      state = state.copyWith(lastSummary: summary);
    };
  }

  Future<void> startSession() async {
    state = state.copyWith(isLoading: true, error: null);
    try {
      await _manager.startSession();
    } catch (e) {
      state = state.copyWith(error: e.toString());
    } finally {
      state = state.copyWith(isLoading: false);
    }
  }

  Future<void> pauseSession() => _manager.pauseSession();
  Future<void> resumeSession() => _manager.resumeSession();

  Future<SessionSummary?> stopSession() async {
    try {
      return await _manager.stopSession();
    } catch (e) {
      state = state.copyWith(error: e.toString());
      return null;
    }
  }
}

class SessionManagerState {
  final SessionState sessionState;
  final bool isLoading;
  final String? error;
  final SessionSummary? lastSummary;

  const SessionManagerState({
    this.sessionState = SessionState.idle,
    this.isLoading = false,
    this.error,
    this.lastSummary,
  });

  SessionManagerState copyWith({
    SessionState? sessionState,
    bool? isLoading,
    String? error,
    SessionSummary? lastSummary,
  }) =>
      SessionManagerState(
        sessionState: sessionState ?? this.sessionState,
        isLoading: isLoading ?? this.isLoading,
        error: error,
        lastSummary: lastSummary ?? this.lastSummary,
      );
}

final sessionManagerProvider = Provider<SessionManager>((ref) {
  return SessionManager(
    locationService: ref.read(locationServiceProvider),
    gridEngine: ref.read(gridEngineProvider),
    sessionRepo: ref.read(sessionRepositoryProvider),
    pointRepo: ref.read(locationPointRepositoryProvider),
    achievementService: ref.read(achievementServiceProvider),
  );
});

final sessionProvider =
    StateNotifierProvider<SessionNotifier, SessionManagerState>((ref) {
  return SessionNotifier(ref.read(sessionManagerProvider));
});
