// lib/data/database/app_database.dart
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' as p;
import '../models/achievement.dart';
import '../../core/constants.dart';
import 'tables.dart';

/// Singleton database accessor.
///
/// BUG 5 FIX: The [initialize] method must complete before the splash screen
/// dismisses. Call [initialize] and await it in main() before runApp, or in
/// the splash screen initState before navigating.
class AppDatabase {
  AppDatabase._();
  static final AppDatabase instance = AppDatabase._();

  Database? _db;

  /// Returns the open database, initializing it if needed.
  Future<Database> get database async {
    _db ??= await _open();
    return _db!;
  }

  bool get isInitialized => _db != null;

  /// Open (or create) the SQLite database and run all migrations.
  /// This MUST complete before the app navigates away from the splash screen.
  Future<void> initialize() async {
    _db = await _open();
  }

  Future<Database> _open() async {
    final dbPath = await getDatabasesPath();
    final fullPath = p.join(dbPath, 'city_grid_explorer.db');

    return openDatabase(
      fullPath,
      version: 1,
      onCreate: _onCreate,
      onUpgrade: _onUpgrade,
    );
  }

  Future<void> _onCreate(Database db, int version) async {
    // Create all tables
    await db.execute(Tables.createGridCells);
    await db.execute(Tables.createGridCellsIndexXY);
    await db.execute(Tables.createGridCellsIndexLastVisited);
    await db.execute(Tables.createExplorationSessions);
    await db.execute(Tables.createLocationPoints);
    await db.execute(Tables.createLocationPointsIndexSession);
    await db.execute(Tables.createLocationPointsIndexTime);
    await db.execute(Tables.createAchievements);
    await db.execute(Tables.createAppSettings);

    // Insert default settings
    await db.execute(Tables.insertDefaultSettings);

    // Seed all achievement rows (all locked, 0 progress)
    final batch = db.batch();
    for (final def in AchievementDefs.all) {
      batch.insert(
        'achievements',
        Achievement(achievementId: def['id'] as String).toMap(),
        conflictAlgorithm: ConflictAlgorithm.ignore,
      );
    }
    await batch.commit(noResult: true);
  }

  Future<void> _onUpgrade(Database db, int oldVersion, int newVersion) async {
    // Future migration logic goes here.
    // Example: if (oldVersion < 2) { await db.execute("ALTER TABLE..."); }
  }

  /// Wipe all exploration data (cells, sessions, points).
  /// Preserves settings and achievement structure (resets progress).
  Future<void> clearHistory() async {
    final db = await database;
    await db.transaction((txn) async {
      await txn.delete('grid_cells');
      await txn.delete('exploration_sessions');
      await txn.delete('location_points');
      await txn.update('achievements', {
        'unlocked_at': null,
        'progress': 0.0,
      });
    });
  }

  Future<void> close() async {
    await _db?.close();
    _db = null;
  }
}
