// lib/data/database/tables.dart

/// SQL strings for creating all tables.
/// These match the schema in PDF §2.5 exactly.
class Tables {
  Tables._();

  static const String createGridCells = '''
    CREATE TABLE IF NOT EXISTS grid_cells (
      cell_id       TEXT PRIMARY KEY,
      grid_x        INTEGER NOT NULL,
      grid_y        INTEGER NOT NULL,
      center_lat    REAL NOT NULL,
      center_lng    REAL NOT NULL,
      state         INTEGER NOT NULL DEFAULT 0,
      first_visited TEXT NOT NULL,
      last_visited  TEXT NOT NULL,
      visit_count   INTEGER NOT NULL DEFAULT 1,
      total_dwell_ms INTEGER NOT NULL DEFAULT 0,
      session_id    TEXT,
      UNIQUE(grid_x, grid_y)
    )
  ''';

  static const String createGridCellsIndexXY = '''
    CREATE INDEX IF NOT EXISTS idx_grid_cells_xy
    ON grid_cells(grid_x, grid_y)
  ''';

  static const String createGridCellsIndexLastVisited = '''
    CREATE INDEX IF NOT EXISTS idx_grid_cells_last_visited
    ON grid_cells(last_visited)
  ''';

  static const String createExplorationSessions = '''
    CREATE TABLE IF NOT EXISTS exploration_sessions (
      session_id       TEXT PRIMARY KEY,
      started_at       TEXT NOT NULL,
      ended_at         TEXT,
      paused_duration  INTEGER DEFAULT 0,
      distance_m       REAL DEFAULT 0.0,
      cells_explored   INTEGER DEFAULT 0,
      cells_transit    INTEGER DEFAULT 0,
      status           INTEGER DEFAULT 0
    )
  ''';

  static const String createLocationPoints = '''
    CREATE TABLE IF NOT EXISTS location_points (
      id         INTEGER PRIMARY KEY AUTOINCREMENT,
      session_id TEXT NOT NULL,
      latitude   REAL NOT NULL,
      longitude  REAL NOT NULL,
      accuracy   REAL NOT NULL,
      speed      REAL,
      altitude   REAL,
      timestamp  TEXT NOT NULL,
      FOREIGN KEY (session_id) REFERENCES exploration_sessions(session_id)
    )
  ''';

  static const String createLocationPointsIndexSession = '''
    CREATE INDEX IF NOT EXISTS idx_location_points_session
    ON location_points(session_id)
  ''';

  static const String createLocationPointsIndexTime = '''
    CREATE INDEX IF NOT EXISTS idx_location_points_time
    ON location_points(timestamp)
  ''';

  static const String createAchievements = '''
    CREATE TABLE IF NOT EXISTS achievements (
      achievement_id TEXT PRIMARY KEY,
      unlocked_at    TEXT,
      progress       REAL DEFAULT 0.0
    )
  ''';

  static const String createAppSettings = '''
    CREATE TABLE IF NOT EXISTS app_settings (
      key   TEXT PRIMARY KEY,
      value TEXT NOT NULL
    )
  ''';

  /// Default settings inserted on first launch (PDF §2.5).
  static const String insertDefaultSettings = '''
    INSERT OR IGNORE INTO app_settings (key, value) VALUES
      ('city_name',        'Ankara'),
      ('city_center_lat',  '39.9334'),
      ('city_center_lng',  '32.8597'),
      ('city_radius_km',   '15'),
      ('grid_size_m',      '150'),
      ('unit_system',      'metric'),
      ('show_grid_lines',  'true'),
      ('gradient_days',    '30')
  ''';
}
