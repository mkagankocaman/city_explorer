// lib/data/models/location_point.dart

class LocationPoint {
  final int? id;
  final String sessionId;
  final double lat;
  final double lng;
  final double accuracy;
  final double? speed; // m/s from GPS hardware
  final double? altitude;
  final DateTime timestamp;

  const LocationPoint({
    this.id,
    required this.sessionId,
    required this.lat,
    required this.lng,
    required this.accuracy,
    this.speed,
    this.altitude,
    required this.timestamp,
  });

  Map<String, dynamic> toMap() => {
        if (id != null) 'id': id,
        'session_id': sessionId,
        'latitude': lat,
        'longitude': lng,
        'accuracy': accuracy,
        'speed': speed,
        'altitude': altitude,
        'timestamp': timestamp.toIso8601String(),
      };

  factory LocationPoint.fromMap(Map<String, dynamic> map) => LocationPoint(
        id: map['id'] as int?,
        sessionId: map['session_id'] as String,
        lat: (map['latitude'] as num).toDouble(),
        lng: (map['longitude'] as num).toDouble(),
        accuracy: (map['accuracy'] as num).toDouble(),
        speed: (map['speed'] as num?)?.toDouble(),
        altitude: (map['altitude'] as num?)?.toDouble(),
        timestamp: DateTime.parse(map['timestamp'] as String),
      );
}
