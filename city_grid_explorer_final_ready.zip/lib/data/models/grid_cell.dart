// lib/data/models/grid_cell.dart
import '../../core/utils/date_utils.dart';
import '../../core/constants.dart';

/// The state of a single 150×150m grid cell.
enum CellState {
  unexplored, // 0 — never visited
  transit, // 1 — passed through quickly / by vehicle
  explored, // 2 — walked through at walking pace for ≥45s
}

extension CellStateExtension on CellState {
  int get dbValue => index;

  static CellState fromDb(int value) {
    return CellState.values[value.clamp(0, CellState.values.length - 1)];
  }

  String get label {
    switch (this) {
      case CellState.unexplored:
        return 'Unexplored';
      case CellState.transit:
        return 'Transit';
      case CellState.explored:
        return 'Explored';
    }
  }
}

/// Represents one 150×150m grid square and all we know about it.
class GridCell {
  final String cellId; // e.g., "29622_18678"
  final int gridX;
  final int gridY;
  final double centerLat;
  final double centerLng;
  final CellState state;
  final DateTime firstVisited;
  final DateTime lastVisited;
  final int visitCount; // BUG 2 FIX: incremented only on UPDATE, not INSERT
  final int totalDwellMs;
  final String? sessionId;

  const GridCell({
    required this.cellId,
    required this.gridX,
    required this.gridY,
    required this.centerLat,
    required this.centerLng,
    required this.state,
    required this.firstVisited,
    required this.lastVisited,
    this.visitCount = 1,
    this.totalDwellMs = 0,
    this.sessionId,
  });

  /// How "fresh" the color should be.
  /// 1.0 = just visited (vivid color), 0.15 = visited 30+ days ago (faded).
  double get freshness => AppDateUtils.freshness(
        lastVisited,
        gradientDays: AppConstants.defaultGradientDays,
        minFreshness: AppConstants.minFreshness,
      );

  /// Convert to a map for SQLite insertion/update.
  Map<String, dynamic> toMap() => {
        'cell_id': cellId,
        'grid_x': gridX,
        'grid_y': gridY,
        'center_lat': centerLat,
        'center_lng': centerLng,
        'state': state.dbValue,
        'first_visited': firstVisited.toIso8601String(),
        'last_visited': lastVisited.toIso8601String(),
        'visit_count': visitCount,
        'total_dwell_ms': totalDwellMs,
        'session_id': sessionId,
      };

  /// Build a GridCell from a SQLite row map.
  factory GridCell.fromMap(Map<String, dynamic> map) => GridCell(
        cellId: map['cell_id'] as String,
        gridX: map['grid_x'] as int,
        gridY: map['grid_y'] as int,
        centerLat: (map['center_lat'] as num).toDouble(),
        centerLng: (map['center_lng'] as num).toDouble(),
        state:
            CellStateExtension.fromDb(map['state'] as int? ?? 0),
        firstVisited: DateTime.parse(map['first_visited'] as String),
        lastVisited: DateTime.parse(map['last_visited'] as String),
        visitCount: map['visit_count'] as int? ?? 1,
        totalDwellMs: map['total_dwell_ms'] as int? ?? 0,
        sessionId: map['session_id'] as String?,
      );

  GridCell copyWith({
    CellState? state,
    DateTime? lastVisited,
    int? visitCount,
    int? totalDwellMs,
  }) =>
      GridCell(
        cellId: cellId,
        gridX: gridX,
        gridY: gridY,
        centerLat: centerLat,
        centerLng: centerLng,
        state: state ?? this.state,
        firstVisited: firstVisited,
        lastVisited: lastVisited ?? this.lastVisited,
        visitCount: visitCount ?? this.visitCount,
        totalDwellMs: totalDwellMs ?? this.totalDwellMs,
        sessionId: sessionId,
      );

  @override
  String toString() =>
      'GridCell($cellId, state=${state.label}, dwell=${totalDwellMs}ms)';
}
