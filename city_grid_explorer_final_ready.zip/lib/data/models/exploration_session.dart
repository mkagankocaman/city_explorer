// lib/data/models/exploration_session.dart

enum SessionStatus {
  active, // 0
  paused, // 1
  completed, // 2
}

extension SessionStatusExtension on SessionStatus {
  int get dbValue => index;

  static SessionStatus fromDb(int value) {
    return SessionStatus.values[value.clamp(0, SessionStatus.values.length - 1)];
  }
}

class ExplorationSession {
  final String sessionId;
  final DateTime startedAt;
  final DateTime? endedAt;
  final int pausedDurationMs; // BUG 3 FIX: tracked separately
  final double distanceMeters;
  final int cellsExplored;
  final int cellsTransit;
  final SessionStatus status;

  const ExplorationSession({
    required this.sessionId,
    required this.startedAt,
    this.endedAt,
    this.pausedDurationMs = 0,
    this.distanceMeters = 0.0,
    this.cellsExplored = 0,
    this.cellsTransit = 0,
    this.status = SessionStatus.active,
  });

  /// Actual active tracking duration (excludes paused time).
  Duration get activeDuration {
    final end = endedAt ?? DateTime.now();
    final total = end.difference(startedAt).inMilliseconds;
    return Duration(milliseconds: total - pausedDurationMs);
  }

  Map<String, dynamic> toMap() => {
        'session_id': sessionId,
        'started_at': startedAt.toIso8601String(),
        'ended_at': endedAt?.toIso8601String(),
        'paused_duration': pausedDurationMs,
        'distance_m': distanceMeters,
        'cells_explored': cellsExplored,
        'cells_transit': cellsTransit,
        'status': status.dbValue,
      };

  factory ExplorationSession.fromMap(Map<String, dynamic> map) =>
      ExplorationSession(
        sessionId: map['session_id'] as String,
        startedAt: DateTime.parse(map['started_at'] as String),
        endedAt: map['ended_at'] != null
            ? DateTime.parse(map['ended_at'] as String)
            : null,
        pausedDurationMs: map['paused_duration'] as int? ?? 0,
        distanceMeters: (map['distance_m'] as num?)?.toDouble() ?? 0.0,
        cellsExplored: map['cells_explored'] as int? ?? 0,
        cellsTransit: map['cells_transit'] as int? ?? 0,
        status: SessionStatusExtension.fromDb(map['status'] as int? ?? 0),
      );

  ExplorationSession copyWith({
    DateTime? endedAt,
    int? pausedDurationMs,
    double? distanceMeters,
    int? cellsExplored,
    int? cellsTransit,
    SessionStatus? status,
  }) =>
      ExplorationSession(
        sessionId: sessionId,
        startedAt: startedAt,
        endedAt: endedAt ?? this.endedAt,
        pausedDurationMs: pausedDurationMs ?? this.pausedDurationMs,
        distanceMeters: distanceMeters ?? this.distanceMeters,
        cellsExplored: cellsExplored ?? this.cellsExplored,
        cellsTransit: cellsTransit ?? this.cellsTransit,
        status: status ?? this.status,
      );
}
