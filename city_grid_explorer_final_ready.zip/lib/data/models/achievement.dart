// lib/data/models/achievement.dart

class Achievement {
  final String achievementId;
  final DateTime? unlockedAt; // null = locked
  final double progress; // 0.0 to 1.0

  const Achievement({
    required this.achievementId,
    this.unlockedAt,
    this.progress = 0.0,
  });

  bool get isUnlocked => unlockedAt != null;

  Map<String, dynamic> toMap() => {
        'achievement_id': achievementId,
        'unlocked_at': unlockedAt?.toIso8601String(),
        'progress': progress,
      };

  factory Achievement.fromMap(Map<String, dynamic> map) => Achievement(
        achievementId: map['achievement_id'] as String,
        unlockedAt: map['unlocked_at'] != null
            ? DateTime.parse(map['unlocked_at'] as String)
            : null,
        progress: (map['progress'] as num?)?.toDouble() ?? 0.0,
      );

  Achievement copyWith({DateTime? unlockedAt, double? progress}) =>
      Achievement(
        achievementId: achievementId,
        unlockedAt: unlockedAt ?? this.unlockedAt,
        progress: progress ?? this.progress,
      );
}
