// lib/data/repositories/location_point_repository.dart
import 'package:sqflite/sqflite.dart';
import '../database/app_database.dart';
import '../models/location_point.dart';

class LocationPointRepository {
  final AppDatabase _appDb;
  LocationPointRepository(this._appDb);

  Future<Database> get _db => _appDb.database;

  Future<void> insertBatch(List<LocationPoint> points) async {
    if (points.isEmpty) return;
    final db = await _db;
    final batch = db.batch();
    for (final p in points) {
      batch.insert(
        'location_points',
        p.toMap(),
        conflictAlgorithm: ConflictAlgorithm.ignore,
      );
    }
    await batch.commit(noResult: true);
  }

  Future<List<LocationPoint>> getForSession(String sessionId) async {
    final db = await _db;
    final rows = await db.query(
      'location_points',
      where: 'session_id = ?',
      whereArgs: [sessionId],
      orderBy: 'timestamp ASC',
    );
    return rows.map(LocationPoint.fromMap).toList();
  }
}
