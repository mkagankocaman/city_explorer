// lib/data/repositories/grid_repository.dart
import 'package:sqflite/sqflite.dart';
import '../database/app_database.dart';
import '../models/grid_cell.dart';

/// All SQLite operations for the grid_cells table.
///
/// BUG 1 FIX: [countByState] uses WHERE state = 2 so only "explored" cells
///            are counted for achievements — not transit or unexplored.
///
/// BUG 2 FIX: [upsertCell] increments visit_count only on UPDATE (conflict),
///            not on INSERT. The initial row starts with visit_count = 1.
class GridRepository {
  final AppDatabase _appDb;

  GridRepository(this._appDb);

  Future<Database> get _db => _appDb.database;

  // ── Read ─────────────────────────────────────────────────────────

  Future<GridCell?> getCell(String cellId) async {
    final db = await _db;
    final rows = await db.query(
      'grid_cells',
      where: 'cell_id = ?',
      whereArgs: [cellId],
      limit: 1,
    );
    if (rows.isEmpty) return null;
    return GridCell.fromMap(rows.first);
  }

  /// Load only cells within the viewport bounds — for map rendering.
  /// Only returns cells that are NOT unexplored (state > 0).
  Future<List<GridCell>> getCellsInBounds({
    required int minX,
    required int minY,
    required int maxX,
    required int maxY,
  }) async {
    final db = await _db;
    final rows = await db.query(
      'grid_cells',
      where:
          'grid_x BETWEEN ? AND ? AND grid_y BETWEEN ? AND ? AND state > 0',
      whereArgs: [minX, maxX, minY, maxY],
    );
    return rows.map(GridCell.fromMap).toList();
  }

  /// Count cells in a specific state.
  ///
  /// BUG 1 FIX: For achievements, ALWAYS call this with CellState.explored.
  /// Passing CellState.unexplored or CellState.transit would count the wrong cells.
  Future<int> countByState(CellState state) async {
    final db = await _db;
    final result = await db.rawQuery(
      'SELECT COUNT(*) as cnt FROM grid_cells WHERE state = ?',
      [state.dbValue],
    );
    return result.first['cnt'] as int? ?? 0;
  }

  /// Total cells in the database (explored + transit — excludes unexplored
  /// because unexplored cells are never inserted into the DB).
  Future<int> totalVisitedCount() async {
    final db = await _db;
    final result = await db
        .rawQuery('SELECT COUNT(*) as cnt FROM grid_cells');
    return result.first['cnt'] as int? ?? 0;
  }

  Future<List<GridCell>> getRecentCells({int limit = 50}) async {
    final db = await _db;
    final rows = await db.query(
      'grid_cells',
      where: 'state = ?',
      whereArgs: [CellState.explored.dbValue],
      orderBy: 'last_visited DESC',
      limit: limit,
    );
    return rows.map(GridCell.fromMap).toList();
  }

  // ── Write ─────────────────────────────────────────────────────────

  /// Insert a new cell OR update an existing one.
  ///
  /// BUG 2 FIX:
  ///   - On first INSERT → visit_count starts at 1 (set in the model constructor).
  ///   - On UPDATE (conflict) → visit_count is incremented by 1.
  ///   We never increment on INSERT because the initial count IS 1.
  Future<void> upsertCell(GridCell cell) async {
    final db = await _db;
    await db.rawInsert('''
      INSERT INTO grid_cells
        (cell_id, grid_x, grid_y, center_lat, center_lng,
         state, first_visited, last_visited, visit_count, total_dwell_ms, session_id)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(cell_id) DO UPDATE SET
        state         = CASE WHEN excluded.state > state THEN excluded.state ELSE state END,
        last_visited  = excluded.last_visited,
        visit_count   = visit_count + 1,
        total_dwell_ms = total_dwell_ms + excluded.total_dwell_ms
    ''', [
      cell.cellId,
      cell.gridX,
      cell.gridY,
      cell.centerLat,
      cell.centerLng,
      cell.state.dbValue,
      cell.firstVisited.toIso8601String(),
      cell.lastVisited.toIso8601String(),
      cell.visitCount,
      cell.totalDwellMs,
      cell.sessionId,
    ]);
  }

  /// Manually override a cell's state (long-press on map, PDF §4.6).
  Future<void> updateCellState(String cellId, CellState newState) async {
    final db = await _db;
    await db.update(
      'grid_cells',
      {
        'state': newState.dbValue,
        'last_visited': DateTime.now().toIso8601String(),
      },
      where: 'cell_id = ?',
      whereArgs: [cellId],
    );
  }

  /// Delete all explored/transit cells (clear history).
  Future<void> clearAll() async {
    final db = await _db;
    await db.delete('grid_cells');
  }
}
