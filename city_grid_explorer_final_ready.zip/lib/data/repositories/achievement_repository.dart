// lib/data/repositories/achievement_repository.dart
import 'package:sqflite/sqflite.dart';
import '../database/app_database.dart';
import '../models/achievement.dart';

class AchievementRepository {
  final AppDatabase _appDb;
  AchievementRepository(this._appDb);

  Future<Database> get _db => _appDb.database;

  Future<List<Achievement>> getAll() async {
    final db = await _db;
    final rows = await db.query('achievements');
    return rows.map(Achievement.fromMap).toList();
  }

  Future<Achievement?> get(String achievementId) async {
    final db = await _db;
    final rows = await db.query(
      'achievements',
      where: 'achievement_id = ?',
      whereArgs: [achievementId],
      limit: 1,
    );
    if (rows.isEmpty) return null;
    return Achievement.fromMap(rows.first);
  }

  Future<void> unlock(String achievementId, DateTime unlockedAt) async {
    final db = await _db;
    await db.update(
      'achievements',
      {
        'unlocked_at': unlockedAt.toIso8601String(),
        'progress': 1.0,
      },
      where: 'achievement_id = ? AND unlocked_at IS NULL',
      whereArgs: [achievementId],
    );
  }

  Future<void> updateProgress(String achievementId, double progress) async {
    final db = await _db;
    await db.update(
      'achievements',
      {'progress': progress.clamp(0.0, 1.0)},
      where: 'achievement_id = ? AND unlocked_at IS NULL',
      whereArgs: [achievementId],
    );
  }

  Future<void> resetAll() async {
    final db = await _db;
    await db.update('achievements', {
      'unlocked_at': null,
      'progress': 0.0,
    });
  }
}

