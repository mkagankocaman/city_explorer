// lib/data/repositories/session_repository.dart
import 'package:sqflite/sqflite.dart';
import '../database/app_database.dart';
import '../models/exploration_session.dart';

class SessionRepository {
  final AppDatabase _appDb;
  SessionRepository(this._appDb);

  Future<Database> get _db => _appDb.database;

  Future<void> createSession(ExplorationSession session) async {
    final db = await _db;
    await db.insert('exploration_sessions', session.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<ExplorationSession?> getSession(String sessionId) async {
    final db = await _db;
    final rows = await db.query(
      'exploration_sessions',
      where: 'session_id = ?',
      whereArgs: [sessionId],
      limit: 1,
    );
    if (rows.isEmpty) return null;
    return ExplorationSession.fromMap(rows.first);
  }

  Future<List<ExplorationSession>> getCompletedSessions() async {
    final db = await _db;
    final rows = await db.query(
      'exploration_sessions',
      where: 'status = ?',
      whereArgs: [SessionStatus.completed.dbValue],
      orderBy: 'started_at DESC',
    );
    return rows.map(ExplorationSession.fromMap).toList();
  }

  Future<void> updateSession(ExplorationSession session) async {
    final db = await _db;
    await db.update(
      'exploration_sessions',
      session.toMap(),
      where: 'session_id = ?',
      whereArgs: [session.sessionId],
    );
  }

  Future<void> pauseSession(String sessionId) async {
    final db = await _db;
    await db.update(
      'exploration_sessions',
      {'status': SessionStatus.paused.dbValue},
      where: 'session_id = ?',
      whereArgs: [sessionId],
    );
  }

  Future<void> resumeSession(String sessionId) async {
    final db = await _db;
    await db.update(
      'exploration_sessions',
      {'status': SessionStatus.active.dbValue},
      where: 'session_id = ?',
      whereArgs: [sessionId],
    );
  }

  Future<void> endSession(
    String sessionId,
    DateTime endedAt,
    int pausedDurationMs,
  ) async {
    final db = await _db;
    await db.update(
      'exploration_sessions',
      {
        'ended_at': endedAt.toIso8601String(),
        'paused_duration': pausedDurationMs,
        'status': SessionStatus.completed.dbValue,
      },
      where: 'session_id = ?',
      whereArgs: [sessionId],
    );
  }

  Future<void> updateProgress(
    String sessionId, {
    required double distanceMeters,
    required int cellsExplored,
    required int cellsTransit,
  }) async {
    final db = await _db;
    await db.update(
      'exploration_sessions',
      {
        'distance_m': distanceMeters,
        'cells_explored': cellsExplored,
        'cells_transit': cellsTransit,
      },
      where: 'session_id = ?',
      whereArgs: [sessionId],
    );
  }

  /// Total distance walked across all completed sessions.
  Future<double> totalDistanceMeters() async {
    final db = await _db;
    final result = await db.rawQuery(
      'SELECT SUM(distance_m) as total FROM exploration_sessions WHERE status = ?',
      [SessionStatus.completed.dbValue],
    );
    return (result.first['total'] as num?)?.toDouble() ?? 0.0;
  }

  Future<int> completedSessionCount() async {
    final db = await _db;
    final result = await db.rawQuery(
      'SELECT COUNT(*) as cnt FROM exploration_sessions WHERE status = ?',
      [SessionStatus.completed.dbValue],
    );
    return result.first['cnt'] as int? ?? 0;
  }
}
