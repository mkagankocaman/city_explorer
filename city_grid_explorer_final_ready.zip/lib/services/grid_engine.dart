// lib/services/grid_engine.dart
import '../core/utils/geo_math.dart';
import '../data/models/grid_cell.dart';
import '../data/models/location_point.dart';
import '../data/repositories/grid_repository.dart';
import 'classifier_engine.dart';

/// Receives filtered GPS points and updates the grid accordingly.
/// Maintains an in-memory buffer of points per cell for classification.
class GridEngine {
  final GridRepository _gridRepo;
  final ClassifierEngine _classifier;

  /// In-memory buffer: cellId → list of GPS points seen this session.
  final Map<String, List<LocationPoint>> _cellPointBuffer = {};

  /// Callback: fires whenever a cell's state changes.
  /// Used by the map provider to update the GeoJSON overlay incrementally
  /// (instead of rebuilding the whole GeoJSON on every GPS point).
  void Function(GridCell cell)? onCellUpdated;

  GridEngine(this._gridRepo, this._classifier);

  // ── Process a single GPS point ─────────────────────────────────────

  Future<void> processPoint(LocationPoint point, String sessionId) async {
    final (gridX, gridY) = GeoMath.latLngToGrid(point.lat, point.lng);
    final cellId = GeoMath.makeCellId(gridX, gridY);

    // Add point to the in-memory buffer for this cell
    _cellPointBuffer.putIfAbsent(cellId, () => []).add(point);

    // Re-classify the cell based on accumulated points
    final newState = _classifier.classify(_cellPointBuffer[cellId]!);

    // Fetch existing cell to detect state transitions
    final existing = await _gridRepo.getCell(cellId);
    final prevState = existing?.state ?? CellState.unexplored;

    // Only persist if state changed, or this is the first visit
    if (existing == null || newState.index > prevState.index) {
      final (centerLat, centerLng) = GeoMath.gridToLatLng(gridX, gridY);

      final updatedCell = GridCell(
        cellId: cellId,
        gridX: gridX,
        gridY: gridY,
        centerLat: centerLat,
        centerLng: centerLng,
        state: newState,
        firstVisited: existing?.firstVisited ?? point.timestamp,
        lastVisited: point.timestamp,
        // BUG 2 FIX: visit_count starts at 1 on INSERT.
        // The upsertCell SQL increments it only on UPDATE (conflict).
        visitCount: 1,
        totalDwellMs: _computeDwellMs(_cellPointBuffer[cellId]!),
        sessionId: sessionId,
      );

      await _gridRepo.upsertCell(updatedCell);
      onCellUpdated?.call(updatedCell);
    }
  }

  /// Flush all in-memory cell state (called when a session ends).
  void clearBuffer() {
    _cellPointBuffer.clear();
  }

  // ── Helpers ────────────────────────────────────────────────────────

  /// Sum the time between consecutive GPS points as dwell time (ms).
  int _computeDwellMs(List<LocationPoint> points) {
    if (points.length < 2) return 0;
    final sorted = List.of(points)
      ..sort((a, b) => a.timestamp.compareTo(b.timestamp));
    return sorted.last.timestamp
        .difference(sorted.first.timestamp)
        .inMilliseconds;
  }
}
