// lib/services/session_manager.dart
import 'dart:async';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';
import 'package:uuid/uuid.dart';
import '../core/constants.dart';
import '../core/utils/geo_math.dart';
import '../data/models/exploration_session.dart';
import '../data/models/location_point.dart';
import '../data/models/grid_cell.dart';
import '../data/repositories/session_repository.dart';
import '../data/repositories/location_point_repository.dart';
    show LocationPointRepository;
import 'location_service.dart';
import 'grid_engine.dart';
import 'achievement_service.dart';

enum SessionState { idle, active, paused }

class SessionSummary {
  final String sessionId;
  final Duration activeDuration;
  final double distanceMeters;
  final int cellsExplored;
  final int cellsTransit;
  final List<String> newAchievements;

  const SessionSummary({
    required this.sessionId,
    required this.activeDuration,
    required this.distanceMeters,
    required this.cellsExplored,
    required this.cellsTransit,
    required this.newAchievements,
  });
}

/// Orchestrates the full session lifecycle.
///
/// BUG 3 FIX: Dwell time tracking is session-based. The GridEngine only
/// receives GPS points while the session is ACTIVE (not paused). When
/// paused, we record _pauseStart; when resumed, we record _pausedDurationMs.
/// The total paused time is tracked here, not in the GridEngine.
class SessionManager {
  final LocationService _locationService;
  final GridEngine _gridEngine;
  final SessionRepository _sessionRepo;
  final LocationPointRepository _pointRepo;
  final AchievementService _achievementService;

  StreamSubscription<LocationPoint>? _locationSub;
  String? _activeSessionId;

  // ── Pause tracking (BUG 3 FIX) ────────────────────────────────────
  DateTime? _pauseStart;
  int _totalPausedMs = 0;

  // ── In-flight stats ────────────────────────────────────────────────
  double _sessionDistanceM = 0.0;
  LocationPoint? _lastPoint;
  int _cellsExplored = 0;
  int _cellsTransit = 0;

  // Point buffer for batch DB writes
  final List<LocationPoint> _pointBuffer = [];
  static const int _bufferFlushSize = AppConstants.locationBufferFlushSize;

  // State notifier callback for providers
  void Function(SessionState)? onStateChanged;
  void Function(SessionSummary)? onSessionCompleted;

  SessionState _state = SessionState.idle;
  SessionState get state => _state;

  SessionManager({
    required LocationService locationService,
    required GridEngine gridEngine,
    required SessionRepository sessionRepo,
    required LocationPointRepository pointRepo,
    required AchievementService achievementService,
  })  : _locationService = locationService,
        _gridEngine = gridEngine,
        _sessionRepo = sessionRepo,
        _pointRepo = pointRepo,
        _achievementService = achievementService;

  // ── Start ──────────────────────────────────────────────────────────

  Future<void> startSession() async {
    if (_state != SessionState.idle) return;

    _activeSessionId = const Uuid().v4();
    _totalPausedMs = 0;
    _sessionDistanceM = 0.0;
    _cellsExplored = 0;
    _cellsTransit = 0;
    _lastPoint = null;
    _pointBuffer.clear();

    final session = ExplorationSession(
      sessionId: _activeSessionId!,
      startedAt: DateTime.now(),
      status: SessionStatus.active,
    );

    await _sessionRepo.createSession(session);
    await _initForegroundService();
    await _locationService.startTracking(_activeSessionId!);

    _locationSub = _locationService.filteredPoints.listen(_onFilteredPoint);

    // Register cell update callback to track explored/transit counts
    _gridEngine.onCellUpdated = _onCellUpdated;

    _state = SessionState.active;
    onStateChanged?.call(_state);
  }

  // ── Pause ──────────────────────────────────────────────────────────

  Future<void> pauseSession() async {
    if (_state != SessionState.active) return;

    // BUG 3 FIX: Stop receiving GPS points — dwell time stops accumulating
    _locationSub?.cancel();
    _locationService.stopTracking();
    _pauseStart = DateTime.now(); // Record when we paused

    await _flushBuffer();
    await _sessionRepo.pauseSession(_activeSessionId!);

    _state = SessionState.paused;
    onStateChanged?.call(_state);
  }

  // ── Resume ─────────────────────────────────────────────────────────

  Future<void> resumeSession() async {
    if (_state != SessionState.paused) return;

    // BUG 3 FIX: Add elapsed pause time to the running total
    if (_pauseStart != null) {
      _totalPausedMs +=
          DateTime.now().difference(_pauseStart!).inMilliseconds;
      _pauseStart = null;
    }

    await _locationService.startTracking(_activeSessionId!);
    _locationSub = _locationService.filteredPoints.listen(_onFilteredPoint);
    await _sessionRepo.resumeSession(_activeSessionId!);

    _state = SessionState.active;
    onStateChanged?.call(_state);
  }

  // ── Stop ───────────────────────────────────────────────────────────

  Future<SessionSummary> stopSession() async {
    if (_state == SessionState.idle) {
      return SessionSummary(
        sessionId: '',
        activeDuration: Duration.zero,
        distanceMeters: 0,
        cellsExplored: 0,
        cellsTransit: 0,
        newAchievements: [],
      );
    }

    // If paused when stopped, account for final pause window
    if (_state == SessionState.paused && _pauseStart != null) {
      _totalPausedMs +=
          DateTime.now().difference(_pauseStart!).inMilliseconds;
    }

    _locationSub?.cancel();
    _locationService.stopTracking();

    await _flushBuffer();
    _gridEngine.clearBuffer();
    _gridEngine.onCellUpdated = null;

    final now = DateTime.now();
    await _sessionRepo.endSession(_activeSessionId!, now, _totalPausedMs);
    await _sessionRepo.updateProgress(
      _activeSessionId!,
      distanceMeters: _sessionDistanceM,
      cellsExplored: _cellsExplored,
      cellsTransit: _cellsTransit,
    );

    await _stopForegroundService();

    // Check achievements after session ends
    final newAchievements =
        await _achievementService.checkAfterSession(_activeSessionId!);

    // Build summary
    final session = await _sessionRepo.getSession(_activeSessionId!);
    final summary = SessionSummary(
      sessionId: _activeSessionId!,
      activeDuration: session?.activeDuration ?? Duration.zero,
      distanceMeters: _sessionDistanceM,
      cellsExplored: _cellsExplored,
      cellsTransit: _cellsTransit,
      newAchievements: newAchievements,
    );

    _activeSessionId = null;
    _state = SessionState.idle;
    onStateChanged?.call(_state);
    onSessionCompleted?.call(summary);

    return summary;
  }

  // ── Internal ───────────────────────────────────────────────────────

  void _onFilteredPoint(LocationPoint point) {
    // Accumulate distance
    if (_lastPoint != null) {
      _sessionDistanceM += GeoMath.haversineDistance(
        _lastPoint!.lat,
        _lastPoint!.lng,
        point.lat,
        point.lng,
      );
    }
    _lastPoint = point;

    // Buffer for batch DB write
    _pointBuffer.add(point);

    // Feed to grid engine for real-time cell updates
    _gridEngine.processPoint(point, _activeSessionId!);

    // Flush buffer when full
    if (_pointBuffer.length >= _bufferFlushSize) {
      _flushBuffer();
    }
  }

  void _onCellUpdated(GridCell cell) {
    // GridEngine only fires this callback when a cell transitions to a new
    // state (not on every GPS point), so every call here is a genuine change.
    if (cell.state == CellState.explored) {
      _cellsExplored++;
    } else if (cell.state == CellState.transit) {
      _cellsTransit++;
    }
  }

  Future<void> _flushBuffer() async {
    if (_pointBuffer.isEmpty) return;
    // Write all buffered GPS points in a single batch transaction.
    // This is more efficient than one INSERT per point (PDF §5.5).
    await _pointRepo.insertBatch(List.of(_pointBuffer));
    _pointBuffer.clear();
  }

  // ── Foreground service (Android) ───────────────────────────────────

  Future<void> _initForegroundService() async {
    FlutterForegroundTask.init(
      androidNotificationOptions: AndroidNotificationOptions(
        channelId: 'explore_session',
        channelName: 'Exploration Tracking',
        channelDescription: 'CityGrid is tracking your walk session',
        channelImportance: NotificationChannelImportance.LOW,
        priority: NotificationPriority.LOW,
      ),
      iosNotificationOptions: const IOSNotificationOptions(
        showNotification: true,
        playSound: false,
      ),
      foregroundTaskOptions: const ForegroundTaskOptions(
        eventAction: ForegroundTaskEventAction.repeat(5000),
        autoRunOnBoot: false,
        allowWakeLock: true,
        allowWifiLock: false,
      ),
    );

    await FlutterForegroundTask.startService(
      serviceId: 100,
      notificationTitle: 'Exploring...',
      notificationText: 'CityGrid is tracking your walk',
    );
  }

  Future<void> _stopForegroundService() async {
    await FlutterForegroundTask.stopService();
  }
}
