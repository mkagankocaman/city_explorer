// lib/services/achievement_service.dart
import '../core/constants.dart';
import '../core/utils/date_utils.dart';
import '../data/models/grid_cell.dart';
import '../data/repositories/achievement_repository.dart';
import '../data/repositories/grid_repository.dart';
import '../data/repositories/session_repository.dart';

/// Checks and unlocks achievement badges after each session.
///
/// BUG 1 FIX: [_countExplored] uses CellState.explored exclusively.
/// We NEVER count transit or unexplored cells toward achievement thresholds.
class AchievementService {
  final AchievementRepository _achievementRepo;
  final GridRepository _gridRepo;
  final SessionRepository _sessionRepo;

  AchievementService({
    required AchievementRepository achievementRepo,
    required GridRepository gridRepo,
    required SessionRepository sessionRepo,
  })  : _achievementRepo = achievementRepo,
        _gridRepo = gridRepo,
        _sessionRepo = sessionRepo;

  /// Check all achievements and unlock newly earned ones.
  /// Returns IDs of newly unlocked achievements.
  Future<List<String>> checkAfterSession(String sessionId) async {
    final newlyUnlocked = <String>[];
    final now = DateTime.now();

    // BUG 1 FIX: Count ONLY cells with state = "explored"
    final totalExplored =
        await _gridRepo.countByState(CellState.explored);
    final totalDistanceM = await _sessionRepo.totalDistanceMeters();
    final totalSessions = await _sessionRepo.completedSessionCount();

    for (final def in AchievementDefs.all) {
      final id = def['id'] as String;
      final existing = await _achievementRepo.get(id);

      // Skip if already unlocked
      if (existing?.isUnlocked ?? false) continue;

      bool shouldUnlock = false;
      double progress = 0.0;

      final type = def['type'] as String;
      final threshold = (def['threshold'] as num).toDouble();

      switch (type) {
        case 'cells':
          // BUG 1 FIX: Only explored cells count here
          progress = threshold > 0
              ? (totalExplored / threshold).clamp(0.0, 1.0)
              : 0.0;
          shouldUnlock = totalExplored >= threshold;

        case 'distance_km':
          final km = totalDistanceM / 1000.0;
          progress = threshold > 0 ? (km / threshold).clamp(0.0, 1.0) : 0.0;
          shouldUnlock = km >= threshold;

        case 'sessions':
          progress = threshold > 0
              ? (totalSessions / threshold).clamp(0.0, 1.0)
              : 0.0;
          shouldUnlock = totalSessions >= threshold;

        case 'time_of_day':
          // Night Owl: check if this session started at night
          final session = await _sessionRepo.getSession(sessionId);
          if (session != null) {
            shouldUnlock = AppDateUtils.isNightTime(session.startedAt);
            progress = shouldUnlock ? 1.0 : 0.0;
          }

        case 'day_of_week':
          // Weekend Warrior: check if session was on weekend
          final session = await _sessionRepo.getSession(sessionId);
          if (session != null) {
            shouldUnlock = AppDateUtils.isWeekend(session.startedAt);
            progress = shouldUnlock ? 1.0 : 0.0;
          }
      }

      // Update progress even if not yet unlocked
      await _achievementRepo.updateProgress(id, progress);

      if (shouldUnlock) {
        await _achievementRepo.unlock(id, now);
        newlyUnlocked.add(id);
      }
    }

    return newlyUnlocked;
  }
}
