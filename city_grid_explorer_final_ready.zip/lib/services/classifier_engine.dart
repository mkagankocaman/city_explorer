// lib/services/classifier_engine.dart
import '../core/constants.dart';
import '../core/utils/geo_math.dart';
import '../data/models/grid_cell.dart';
import '../data/models/location_point.dart';

/// Classifies a cell as explored, transit, or unexplored
/// based on the GPS points collected inside it.
///
/// Implements the algorithm from PDF §4.3 exactly.
class ClassifierEngine {
  ClassifierEngine._();
  static final ClassifierEngine instance = ClassifierEngine._();

  // ── Public API ────────────────────────────────────────────────────

  /// Given all GPS points collected inside a single cell,
  /// return the appropriate [CellState].
  CellState classify(List<LocationPoint> pointsInCell) {
    // Step 1: Filter out low-accuracy points
    final valid = pointsInCell
        .where((p) => p.accuracy <= AppConstants.maxGpsAccuracyMeters)
        .toList();

    if (valid.length < AppConstants.minPointsInCell) {
      return CellState.unexplored; // Not enough reliable data
    }

    // Step 2: Calculate metrics
    valid.sort((a, b) => a.timestamp.compareTo(b.timestamp));

    final dwellTimeSec = valid.last.timestamp
        .difference(valid.first.timestamp)
        .inMilliseconds /
        1000.0;

    final avgSpeed = smoothedSpeed(valid);
    final distanceInCell = _sumDistances(valid);

    // Step 3: Quick rejection — probably GPS noise
    if (dwellTimeSec < AppConstants.minDwellForTransitSec) {
      return CellState.unexplored;
    }

    // Step 4: Speed-based primary classification
    if (avgSpeed > AppConstants.maxRunningSpeedMs) {
      // Definitely in a vehicle
      return CellState.transit;
    }

    if (avgSpeed > AppConstants.maxWalkingSpeedMs) {
      // Fast movement — running or slow vehicle
      return CellState.transit;
    }

    // Step 5: Walking speed confirmed — check thoroughness
    if (dwellTimeSec >= AppConstants.minDwellForExploredSec) {
      // Dwell time met — regardless of distance (could be standing at a corner)
      return CellState.explored;
    }

    if (dwellTimeSec >= 15) {
      // Walked through quickly but at walking speed
      return CellState.transit;
    }

    return CellState.transit;
  }

  // ── Speed smoothing (PDF §4.4) ─────────────────────────────────────

  /// Compute smoothed speed using the MEDIAN of the last N point-to-point
  /// speeds. Median is chosen over mean to reject GPS speed spikes.
  double smoothedSpeed(
    List<LocationPoint> points, {
    int window = AppConstants.speedSmoothingWindow,
  }) {
    if (points.length < 2) return 0.0;

    final recent = points.length <= window
        ? points
        : points.sublist(points.length - window);

    final speeds = <double>[];
    for (var i = 1; i < recent.length; i++) {
      final dist = GeoMath.haversineDistance(
        recent[i - 1].lat,
        recent[i - 1].lng,
        recent[i].lat,
        recent[i].lng,
      );
      final dtMs = recent[i]
          .timestamp
          .difference(recent[i - 1].timestamp)
          .inMilliseconds;
      if (dtMs > 0) {
        speeds.add(dist / (dtMs / 1000.0)); // m/s
      }
    }

    if (speeds.isEmpty) return 0.0;
    speeds.sort();
    return speeds[speeds.length ~/ 2]; // Median
  }

  // ── Helpers ────────────────────────────────────────────────────────

  double _sumDistances(List<LocationPoint> points) {
    var total = 0.0;
    for (var i = 1; i < points.length; i++) {
      total += GeoMath.haversineDistance(
        points[i - 1].lat,
        points[i - 1].lng,
        points[i].lat,
        points[i].lng,
      );
    }
    return total;
  }
}
