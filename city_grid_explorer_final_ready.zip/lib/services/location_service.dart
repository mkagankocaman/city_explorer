// lib/services/location_service.dart
import 'dart:async';
import 'package:geolocator/geolocator.dart';
import '../core/constants.dart';
import '../core/utils/geo_math.dart';
import '../data/models/location_point.dart';

/// Wraps the device GPS and applies the 4-stage noise filter from PDF §4.5.
/// Exposes a [filteredPoints] stream that downstream services listen to.
class LocationService {
  StreamSubscription<Position>? _positionSub;

  final _filteredController =
      StreamController<LocationPoint>.broadcast();

  LocationPoint? _lastAccepted;
  DateTime? _stationaryStart;

  /// Stream of validated, noise-filtered GPS points.
  Stream<LocationPoint> get filteredPoints => _filteredController.stream;

  /// Current position (updated on every accepted point).
  LocationPoint? get lastKnownPosition => _lastAccepted;

  /// Walking-optimized GPS settings.
  static const LocationSettings _walkingSettings = LocationSettings(
    accuracy: LocationAccuracy.high,
    distanceFilter: AppConstants.gpsDistanceFilterMeters,
  );

  // ── Permissions ────────────────────────────────────────────────────

  /// Check and request "When In Use" location permission.
  /// Returns true if permission is granted (either existing or just granted).
  Future<bool> ensurePermission() async {
    var permission = await Geolocator.checkPermission();

    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }

    if (permission == LocationPermission.deniedForever) {
      return false;
    }

    return permission == LocationPermission.whileInUse ||
        permission == LocationPermission.always;
  }

  Future<bool> get isPermissionGranted async {
    final p = await Geolocator.checkPermission();
    return p == LocationPermission.whileInUse ||
        p == LocationPermission.always;
  }

  Future<void> openSettings() => Geolocator.openAppSettings();

  // ── Tracking ───────────────────────────────────────────────────────

  /// Start the GPS stream and begin emitting filtered points.
  Future<void> startTracking(String sessionId) async {
    _lastAccepted = null;
    _stationaryStart = null;

    _positionSub = Geolocator.getPositionStream(
      locationSettings: _walkingSettings,
    ).listen((pos) => _onRawPosition(pos, sessionId));
  }

  /// Stop the GPS stream.
  void stopTracking() {
    _positionSub?.cancel();
    _positionSub = null;
    _lastAccepted = null;
    _stationaryStart = null;
  }

  // ── Noise filter pipeline (PDF §4.5) ──────────────────────────────

  void _onRawPosition(Position pos, String sessionId) {
    final now = DateTime.now();

    // ── Stage 1: Accuracy filter ──────────────────────────────────
    if (pos.accuracy > AppConstants.maxGpsAccuracyMeters) return;

    final point = LocationPoint(
      sessionId: sessionId,
      lat: pos.latitude,
      lng: pos.longitude,
      accuracy: pos.accuracy,
      speed: pos.speed >= 0 ? pos.speed : null,
      altitude: pos.altitude,
      timestamp: now,
    );

    if (_lastAccepted != null) {
      final prevLat = _lastAccepted!.lat;
      final prevLng = _lastAccepted!.lng;
      final dtSec = now
              .difference(_lastAccepted!.timestamp)
              .inMilliseconds /
          1000.0;
      final dist =
          GeoMath.haversineDistance(prevLat, prevLng, pos.latitude, pos.longitude);

      // ── Stage 2: Duplicate filter ─────────────────────────────
      if (dtSec < AppConstants.duplicateFilterTimeSec &&
          dist < AppConstants.duplicateFilterDistanceMeters) {
        return;
      }

      // ── Stage 3: Teleport filter ──────────────────────────────
      if (dtSec > 0 &&
          (dist / dtSec) > AppConstants.teleportFilterSpeedMs) {
        return;
      }

      // ── Stage 4: Stationary filter ────────────────────────────
      final speed = dtSec > 0 ? dist / dtSec : 0.0;
      if (speed < AppConstants.stationarySpeedThresholdMs) {
        _stationaryStart ??= now;
        final stationaryDuration =
            now.difference(_stationaryStart!).inSeconds;
        if (stationaryDuration > AppConstants.stationaryTimeThresholdSec) {
          // Already emitted the "stationary" point; skip until movement
          return;
        }
      } else {
        _stationaryStart = null; // Movement resumed
      }
    }

    _lastAccepted = point;
    _filteredController.add(point);
  }

  // ── One-shot position ──────────────────────────────────────────────

  /// Get the current GPS position once (used for BUG 4: re-center button).
  /// BUG 4 FIX: This returns the ACTUAL current GPS position, never a hardcoded
  /// coordinate.
  Future<({double lat, double lng})?> getCurrentPosition() async {
    try {
      final pos = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
        ),
      );
      return (lat: pos.latitude, lng: pos.longitude);
    } catch (_) {
      // Return last known if live fix fails
      if (_lastAccepted != null) {
        return (lat: _lastAccepted!.lat, lng: _lastAccepted!.lng);
      }
      return null;
    }
  }

  void dispose() {
    stopTracking();
    _filteredController.close();
  }
}
