// lib/core/utils/geo_math.dart
import 'dart:math';
import '../constants.dart';

/// All geographic math lives here.
///
/// Key insight: Earth is (nearly) a sphere.
///   1° of latitude ≈ 111,320 m everywhere.
///   1° of longitude ≈ 111,320 × cos(lat) m — shrinks toward the poles.
///
/// At Ankara (39.93°N): cos(39.93°) ≈ 0.7665
///   → 1° longitude ≈ 85,326 m
class GeoMath {
  // Private constructor — this is a utility class with only static methods.
  GeoMath._();

  static const double _earthRadius = AppConstants.earthRadiusMeters;
  static const double _cellSize = AppConstants.cellSizeMeters;

  // ── Degree step sizes ──────────────────────────────────────────────

  /// Latitude degrees per cell (constant everywhere on Earth).
  /// = 150 / 111320 ≈ 0.001348°
  static double get deltaLat => _cellSize / 111320.0;

  /// Longitude degrees per cell at a given latitude.
  /// = 150 / (111320 × cos(lat))
  /// At Ankara: ≈ 0.001758°
  static double deltaLng(double latitudeDeg) {
    final cosLat = cos(latitudeDeg * pi / 180.0);
    // Guard against division by zero near poles (irrelevant for Ankara)
    if (cosLat.abs() < 1e-10) return deltaLat;
    return _cellSize / (111320.0 * cosLat);
  }

  // ── Coordinate ↔ Grid conversions ─────────────────────────────────

  /// Convert GPS coordinates to grid (gridX, gridY) indices.
  ///
  /// This is the core formula: divide the coordinate space into a grid
  /// where each cell is [deltaLat × deltaLng] degrees in size.
  static (int gridX, int gridY) latLngToGrid(double lat, double lng) {
    final gridY = (lat / deltaLat).floor();
    final gridX = (lng / deltaLng(lat)).floor();
    return (gridX, gridY);
  }

  /// Generate the unique cell ID string from grid indices.
  /// Format: "gridY_gridX" — e.g., "29622_18678"
  static String makeCellId(int gridX, int gridY) => '${gridY}_$gridX';

  /// Parse a cellId string back into (gridX, gridY).
  static (int gridX, int gridY) parseCellId(String cellId) {
    final parts = cellId.split('_');
    if (parts.length < 2) return (0, 0);
    final gridY = int.tryParse(parts[0]) ?? 0;
    final gridX = int.tryParse(parts[1]) ?? 0;
    return (gridX, gridY);
  }

  /// Get the center lat/lng of a grid cell (used for DB storage).
  static (double lat, double lng) gridToLatLng(int gridX, int gridY) {
    final lat = (gridY + 0.5) * deltaLat;
    final lng = (gridX + 0.5) * deltaLng(lat);
    return (lat, lng);
  }

  /// Get the four corners of a cell in (lat, lng) tuples.
  /// Order: SW, SE, NE, NW — matching GeoJSON polygon convention
  /// (when converted to [lng, lat] for GeoJSON).
  static List<(double lat, double lng)> cellCorners(int gridX, int gridY) {
    final south = gridY * deltaLat;
    final north = (gridY + 1) * deltaLat;
    // Use center latitude for longitude calculation (most accurate)
    final midLat = (south + north) / 2.0;
    final dLng = deltaLng(midLat);
    final west = gridX * dLng;
    final east = (gridX + 1) * dLng;

    return [
      (south, west), // SW
      (south, east), // SE
      (north, east), // NE
      (north, west), // NW
    ];
  }

  // ── Distance calculation ───────────────────────────────────────────

  /// Haversine formula: straight-line distance between two GPS points (meters).
  ///
  /// Why not Euclidean distance? On a sphere, straight lines curve.
  /// For small distances (<10 km) the difference is tiny, but haversine
  /// is the correct formula and avoids confusion.
  static double haversineDistance(
    double lat1,
    double lng1,
    double lat2,
    double lng2,
  ) {
    final dLat = (lat2 - lat1) * pi / 180.0;
    final dLng = (lng2 - lng1) * pi / 180.0;
    final a = sin(dLat / 2) * sin(dLat / 2) +
        cos(lat1 * pi / 180.0) *
            cos(lat2 * pi / 180.0) *
            sin(dLng / 2) *
            sin(dLng / 2);
    final c = 2 * atan2(sqrt(a), sqrt(1 - a));
    return _earthRadius * c;
  }

  // ── Viewport helpers ───────────────────────────────────────────────

  /// Get grid X/Y bounds for a map viewport.
  /// Used to query only visible cells from SQLite.
  static ({int minX, int minY, int maxX, int maxY}) viewportGridBounds({
    required double southLat,
    required double westLng,
    required double northLat,
    required double eastLng,
    int buffer = 2,
  }) {
    final (minX, minY) = latLngToGrid(southLat, westLng);
    final (maxX, maxY) = latLngToGrid(northLat, eastLng);
    return (
      minX: minX - buffer,
      minY: minY - buffer,
      maxX: maxX + buffer,
      maxY: maxY + buffer,
    );
  }

  // ── Speed helpers ──────────────────────────────────────────────────

  /// Compute speed (m/s) from two GPS points and elapsed time.
  static double speedBetweenPoints(
    double lat1,
    double lng1,
    double lat2,
    double lng2,
    double elapsedSeconds,
  ) {
    if (elapsedSeconds <= 0) return 0.0;
    return haversineDistance(lat1, lng1, lat2, lng2) / elapsedSeconds;
  }
}
