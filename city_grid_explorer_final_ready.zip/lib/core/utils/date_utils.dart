// lib/core/utils/date_utils.dart
import 'package:intl/intl.dart';

class AppDateUtils {
  AppDateUtils._();

  static final _timeFormat = DateFormat('HH:mm');
  static final _dateFormat = DateFormat('MMM d, yyyy');
  static final _dateTimeFormat = DateFormat('MMM d, yyyy · HH:mm');
  static final _durationFormat = DateFormat('HH:mm:ss');

  /// Format a DateTime as "14:32"
  static String formatTime(DateTime dt) => _timeFormat.format(dt);

  /// Format a DateTime as "May 23, 2026"
  static String formatDate(DateTime dt) => _dateFormat.format(dt);

  /// Format a DateTime as "May 23, 2026 · 14:32"
  static String formatDateTime(DateTime dt) => _dateTimeFormat.format(dt);

  /// Format a duration in seconds as "1h 23m" or "45m 12s"
  static String formatDuration(int totalSeconds) {
    final h = totalSeconds ~/ 3600;
    final m = (totalSeconds % 3600) ~/ 60;
    final s = totalSeconds % 60;
    if (h > 0) return '${h}h ${m}m';
    if (m > 0) return '${m}m ${s}s';
    return '${s}s';
  }

  /// Format milliseconds as "1h 23m" or "45m 12s"
  static String formatDurationMs(int totalMs) =>
      formatDuration(totalMs ~/ 1000);

  /// Relative time: "just now", "5 min ago", "3 days ago"
  static String timeAgo(DateTime dt) {
    final diff = DateTime.now().difference(dt);
    if (diff.inSeconds < 60) return 'just now';
    if (diff.inMinutes < 60) return '${diff.inMinutes} min ago';
    if (diff.inHours < 24) return '${diff.inHours}h ago';
    if (diff.inDays < 7) return '${diff.inDays} days ago';
    return formatDate(dt);
  }

  /// Freshness score: 0.0 (old) → 1.0 (just visited).
  /// Clamped to [minFreshness, 1.0].
  static double freshness(DateTime lastVisited,
      {int gradientDays = 30, double minFreshness = 0.15}) {
    final daysSince = DateTime.now().difference(lastVisited).inDays;
    return (1.0 - (daysSince / gradientDays)).clamp(minFreshness, 1.0);
  }

  /// Returns true if the DateTime falls between 22:00 and 05:00.
  static bool isNightTime(DateTime dt) {
    final hour = dt.hour;
    return hour >= 22 || hour < 5;
  }

  /// Returns true if the DateTime is Saturday (6) or Sunday (7).
  static bool isWeekend(DateTime dt) {
    return dt.weekday == DateTime.saturday || dt.weekday == DateTime.sunday;
  }
}
