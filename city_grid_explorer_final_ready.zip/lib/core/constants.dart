// lib/core/constants.dart
import 'dart:ui';

/// All magic numbers live here. If you need to change a threshold,
/// change it once here and it propagates everywhere.
class AppConstants {
  // ── Grid ──────────────────────────────────────────────────────────
  static const double cellSizeMeters = 150.0;
  static const double earthRadiusMeters = 6371000.0;

  // ── Classification thresholds (PDF §4.2) ──────────────────────────
  /// Above this speed (m/s) → transit. 7 km/h = 1.944 m/s
  static const double maxWalkingSpeedMs = 1.944;

  /// Above this speed (m/s) → definitely transit. 12 km/h = 3.333 m/s
  static const double maxRunningSpeedMs = 3.333;

  /// Min dwell time (seconds) in a cell to be classified "explored"
  static const int minDwellForExploredSec = 45;

  /// Min dwell time (seconds) for "transit" (below this = GPS noise)
  static const int minDwellForTransitSec = 5;

  /// Min walking distance inside a cell for "explored" classification
  static const double minWalkingDistanceMeters = 40.0;

  /// Discard GPS points with accuracy worse than this (meters)
  static const double maxGpsAccuracyMeters = 30.0;

  /// Min GPS points inside a cell before we classify it
  static const int minPointsInCell = 3;

  /// Number of points to use for speed smoothing (median)
  static const int speedSmoothingWindow = 5;

  // ── GPS Noise Filtering (PDF §4.5) ────────────────────────────────
  /// Duplicate filter: reject if < 2s AND < 3m from last point
  static const double duplicateFilterTimeSec = 2.0;
  static const double duplicateFilterDistanceMeters = 3.0;

  /// Teleport filter: reject if implied speed > 200 km/h (55.56 m/s)
  static const double teleportFilterSpeedMs = 55.56;

  /// Stationary filter: if speed < 0.3 m/s for 30+ seconds
  static const double stationarySpeedThresholdMs = 0.3;
  static const int stationaryTimeThresholdSec = 30;

  // ── Distance filter for GPS callbacks ─────────────────────────────
  static const int gpsDistanceFilterMeters = 5;

  // ── DB write buffer ────────────────────────────────────────────────
  static const int locationBufferFlushSize = 10;

  // ── Default city: Ankara ──────────────────────────────────────────
  static const String defaultCityName = 'Ankara';
  static const double defaultCityLat = 39.9334;
  static const double defaultCityLng = 32.8597;
  static const double defaultCityRadiusKm = 15.0;

  // ── Map rendering ─────────────────────────────────────────────────
  static const double cellFillOpacity = 0.55;
  static const double gridLineMinZoom = 15.0;
  static const int mapDebounceMs = 200;
  static const int viewportBufferCells = 2;

  // ── Gradient ──────────────────────────────────────────────────────
  static const int defaultGradientDays = 30;
  static const double minFreshness = 0.15;
}

/// All color tokens used across the app (PDF §6.3).
class AppColors {
  // Explored cells: teal/green gradient based on freshness
  static const Color exploredVivid = Color(0xFF00BFA5); // Just visited
  static const Color exploredFaded = Color(0xFFB2DFDB); // 30+ days ago

  // Transit cells: amber/yellow gradient
  static const Color transitVivid = Color(0xFFFFB300); // Recent transit
  static const Color transitFaded = Color(0xFFFFECB3); // Old transit

  // Grid lines (subtle, 12% black)
  static const Color gridLine = Color(0x20000000);

  // UI palette
  static const Color primary = Color(0xFF00897B);
  static const Color primaryDark = Color(0xFF00695C);
  static const Color accent = Color(0xFFFFB300);
  static const Color background = Color(0xFF121212);
  static const Color surface = Color(0xFF1E1E1E);
  static const Color onPrimary = Color(0xFFFFFFFF);
  static const Color textPrimary = Color(0xFFF5F5F5);
  static const Color textSecondary = Color(0xFF9E9E9E);
  static const Color danger = Color(0xFFEF5350);
  static const Color success = Color(0xFF66BB6A);
}

/// Achievement definitions (PDF Appendix A).
class AchievementDefs {
  static const List<Map<String, dynamic>> all = [
    {
      'id': 'first_cell',
      'name': 'First Step',
      'description': 'Explore your first grid cell',
      'emoji': '👣',
      'type': 'cells',
      'threshold': 1,
    },
    {
      'id': 'ten_cells',
      'name': 'Getting Started',
      'description': 'Explore 10 cells',
      'emoji': '🗺️',
      'type': 'cells',
      'threshold': 10,
    },
    {
      'id': 'hundred_cells',
      'name': 'Explorer',
      'description': 'Explore 100 cells',
      'emoji': '🧭',
      'type': 'cells',
      'threshold': 100,
    },
    {
      'id': 'five_hundred_cells',
      'name': 'City Walker',
      'description': 'Explore 500 cells',
      'emoji': '🏙️',
      'type': 'cells',
      'threshold': 500,
    },
    {
      'id': 'ten_km',
      'name': 'Marathon',
      'description': 'Walk 10 km total across all sessions',
      'emoji': '🏃',
      'type': 'distance_km',
      'threshold': 10,
    },
    {
      'id': 'five_sessions',
      'name': 'Dedicated',
      'description': 'Complete 5 explore sessions',
      'emoji': '⭐',
      'type': 'sessions',
      'threshold': 5,
    },
    {
      'id': 'night_session',
      'name': 'Night Owl',
      'description': 'Start a session between 10 PM and 5 AM',
      'emoji': '🦉',
      'type': 'time_of_day',
      'threshold': 0,
    },
    {
      'id': 'weekend_session',
      'name': 'Weekend Warrior',
      'description': 'Complete a session on Saturday or Sunday',
      'emoji': '🎉',
      'type': 'day_of_week',
      'threshold': 0,
    },
  ];
}
