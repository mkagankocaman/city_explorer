# CityGrid Explorer

A Flutter app that divides your city into a 150×150 m grid and tracks which squares you've explored on foot — like a "fog of war" for your city.

Built for a first-year CS student at METU, Ankara. Targets iOS 16+ and Android API 29+.

---

## Architecture overview

```
UI (Flutter Widgets)
  ↕
State (Riverpod providers)
  ↕
Services (LocationService, GridEngine, ClassifierEngine, SessionManager, AchievementService)
  ↕
Repositories (GridRepository, SessionRepository, AchievementRepository)
  ↕
SQLite (sqflite — stays on-device, never uploaded)
```

---

## Prerequisites

| Tool | Version |
|------|---------|
| Flutter | 3.22+ |
| Dart | 3.2+ |
| Xcode | 15+ (iOS build) |
| Android Studio / SDK | API 34 |

Install Flutter: https://docs.flutter.dev/get-started/install

---

## 1 — Get a Mapbox token

1. Sign up at https://account.mapbox.com (free tier: 25 000 MAU)
2. Create a **public access token** (starts with `pk.`)
3. Create a **secret download token** (starts with `sk.`) — needed to download the Mapbox SDK during build

---

## 2 — Configure the Mapbox token

### Android — secret download token

Add to `~/.gradle/gradle.properties` (create the file if it doesn't exist):

```
MAPBOX_DOWNLOADS_TOKEN=sk.eyJ1...your_secret_token...
```

### iOS — secret download token

Create `~/.netrc` and add:

```
machine api.mapbox.com
  login mapbox
  password sk.eyJ1...your_secret_token...
```

### App — public access token

Pass it at build time via `--dart-define`:

```bash
flutter run --dart-define=MAPBOX_ACCESS_TOKEN=pk.eyJ1...your_public_token...
```

Or hard-code it in `lib/main.dart` (not recommended for production):

```dart
const mapboxToken = 'pk.eyJ1...your_public_token...';
```

---

## 3 — Run the app

```bash
# Get all dependencies
flutter pub get

# Run on Android (USB debugging enabled)
flutter run --dart-define=MAPBOX_ACCESS_TOKEN=pk.eyJ1...

# Run on iOS (requires Mac + Xcode)
flutter run --dart-define=MAPBOX_ACCESS_TOKEN=pk.eyJ1...

# Run tests
flutter test
```

---

## 4 — Building for release

### Android APK / AAB

```bash
# Generate a keystore (first time only — KEEP THIS FILE SAFE)
keytool -genkey -v -keystore android/app/release.keystore \
  -alias city_grid -keyalg RSA -keysize 2048 -validity 10000

# Build release AAB (for Google Play)
flutter build appbundle --dart-define=MAPBOX_ACCESS_TOKEN=pk.eyJ1...

# Or APK (for sideloading)
flutter build apk --dart-define=MAPBOX_ACCESS_TOKEN=pk.eyJ1...
```

Update `android/app/build.gradle` signingConfigs to point to your keystore.

### iOS IPA

```bash
# Open in Xcode first to set your Team ID and Bundle ID
open ios/Runner.xcworkspace

# Then build
flutter build ios --dart-define=MAPBOX_ACCESS_TOKEN=pk.eyJ1...
```

Archive and upload via Xcode → Product → Archive → Distribute App.

---

## 5 — Project structure

```
lib/
  core/         Constants, colors, theme, GeoMath utility
  data/         SQLite schema, models, repositories
  services/     LocationService, GridEngine, ClassifierEngine,
                SessionManager, AchievementService
  providers/    Riverpod state management
  ui/           Screens (map, stats, achievements, settings)
                Widgets (session controls, stats bar)
test/
  services/     GeoMath + ClassifierEngine unit tests
  data/         GridRepository upsert tests
```

---

## 6 — Bug fixes implemented

| # | Bug | Fix |
|---|-----|-----|
| 1 | Achievement counting included transit + unexplored cells | `countByState(CellState.explored)` — only state = 2 |
| 2 | `visitCount` incremented on INSERT and UPDATE | SQL `ON CONFLICT DO UPDATE` increments only on conflict (UPDATE) |
| 3 | Dwell time accumulated while session paused | `SessionManager.pauseSession()` cancels GPS subscription; resumes on `resumeSession()` |
| 4 | Re-center button flew to hardcoded Ankara coordinates | `LocationService.getCurrentPosition()` — always uses actual GPS fix |
| 5 | Splash dismissed before DB initialization finished | `AppDatabase.instance.initialize()` awaited in `main()` before `runApp()` |

---

## 7 — Classification thresholds (PDF §4.2)

| Parameter | Value |
|-----------|-------|
| Max walking speed | 7 km/h (1.944 m/s) |
| Max running speed | 12 km/h (3.333 m/s) |
| Min dwell for "explored" | 45 seconds |
| Min dwell for "transit" | 5 seconds |
| Max GPS accuracy | 30 metres |
| Min GPS points in cell | 3 |
| Speed smoothing | Median of last 5 points |

---

## 8 — Known limitations

- **Mapbox token required**: The app won't show a map without a valid token.
- **No cloud sync**: All data is local-only (by design). Your exploration history lives on-device.
- **Emulator GPS**: The classifier needs real movement to work properly. Test on a physical device.
- **iOS background**: With "When In Use" permission, iOS may suspend the app after ~10 seconds in background on older devices. The `UIBackgroundModes: location` key minimises this.
- **Grid accuracy near 60°N+**: The adaptive longitude correction works for Ankara (39.93°N). At very high latitudes, cells appear visually narrower — acceptable for Turkey.
- **City search**: Currently a preset list. A future version will use Nominatim / Overpass API for arbitrary city search.
- **Achievement icons**: Emoji badges are used instead of custom PNG icons. Replace `assets/badges/` with your own artwork if desired.
- **`sqflite_common_ffi`**: The repository tests require `sqflite_common_ffi` added to `dev_dependencies` for in-memory SQLite in test environments.

---

## 9 — Privacy

- Location data **never leaves the device**.
- Mapbox receives map tile requests (which include your approximate viewport). It does **not** receive your GPS track.
- See `ios/Runner/PrivacyInfo.xcprivacy` for the iOS privacy manifest.
- Host a privacy policy at a public URL before submitting to either store.

---

## 10 — Accounts and costs

| Item | Cost |
|------|------|
| Apple Developer Program | $99/year |
| Google Play Developer | $25 one-time |
| Mapbox (under 25 000 MAU) | Free |
| Hosting for privacy policy | Free (GitHub Pages) |

---

*Total estimated dev time from scratch: 6–8 weeks for a motivated beginner working part-time.*
