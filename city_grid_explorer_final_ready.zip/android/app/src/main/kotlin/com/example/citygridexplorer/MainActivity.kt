// android/app/src/main/kotlin/com/example/citygridexplorer/MainActivity.kt
package com.example.citygridexplorer

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
