// test/services/classifier_engine_test.dart
//
// Dedicated tests for ClassifierEngine threshold combinations.
// Run with: flutter test
import 'package:flutter_test/flutter_test.dart';
import 'package:city_grid_explorer/services/classifier_engine.dart';
import 'package:city_grid_explorer/data/models/grid_cell.dart';
import 'package:city_grid_explorer/data/models/location_point.dart';
import 'package:city_grid_explorer/core/constants.dart';

void main() {
  final classifier = ClassifierEngine.instance;

  /// Build a list of points with a specific speed and duration.
  List<LocationPoint> points({
    required int n,
    required double speedMs,
    required double durationSec,
    double accuracy = 10.0,
    double startLat = 39.9208,
    double startLng = 32.8541,
  }) {
    final now = DateTime.now();
    final result = <LocationPoint>[];
    final interval = n > 1 ? durationSec / (n - 1) : 0.0;
    final latStep = n > 1 ? (speedMs * interval) / 111320.0 : 0.0;

    for (var i = 0; i < n; i++) {
      result.add(LocationPoint(
        sessionId: 'test',
        lat: startLat + latStep * i,
        lng: startLng,
        accuracy: accuracy,
        speed: speedMs,
        timestamp:
            now.add(Duration(milliseconds: (interval * i * 1000).round())),
      ));
    }
    return result;
  }

  group('Threshold boundary tests', () {
    // Max walking speed boundary: 7 km/h = 1.944 m/s
    test('Speed exactly at maxWalkingSpeedMs (1.944) + 45 s → EXPLORED', () {
      final pts = points(
          n: 8, speedMs: AppConstants.maxWalkingSpeedMs, durationSec: 60);
      expect(classifier.classify(pts), equals(CellState.explored));
    });

    test('Speed just above maxWalkingSpeedMs (2.0 m/s) → TRANSIT', () {
      final pts = points(n: 8, speedMs: 2.0, durationSec: 60);
      expect(classifier.classify(pts), equals(CellState.transit));
    });

    // Max running speed boundary: 12 km/h = 3.333 m/s
    test('Speed at maxRunningSpeedMs (3.333) → TRANSIT', () {
      final pts = points(
          n: 6, speedMs: AppConstants.maxRunningSpeedMs, durationSec: 30);
      expect(classifier.classify(pts), equals(CellState.transit));
    });

    test('Speed above maxRunningSpeedMs (4.0 m/s = 14.4 km/h) → TRANSIT', () {
      final pts = points(n: 6, speedMs: 4.0, durationSec: 20);
      expect(classifier.classify(pts), equals(CellState.transit));
    });

    // Min dwell boundary: 45 s
    test('Dwell exactly 45 s at walking speed → EXPLORED', () {
      final pts = points(n: 8, speedMs: 1.2, durationSec: 45);
      expect(classifier.classify(pts), equals(CellState.explored));
    });

    test('Dwell 44 s at walking speed → TRANSIT (just under threshold)', () {
      final pts = points(n: 8, speedMs: 1.2, durationSec: 44);
      expect(classifier.classify(pts), equals(CellState.transit));
    });

    // Min points boundary: 3
    test('Exactly 3 points with good accuracy → classification proceeds', () {
      final pts = points(n: 3, speedMs: 1.2, durationSec: 60);
      final result = classifier.classify(pts);
      // With 3 valid points and 60 s dwell at walking speed → EXPLORED
      expect(result, equals(CellState.explored));
    });

    test('2 points → UNEXPLORED (min 3 required)', () {
      final pts = points(n: 2, speedMs: 1.2, durationSec: 60);
      expect(classifier.classify(pts), equals(CellState.unexplored));
    });

    // Accuracy filter
    test('3 points with accuracy 30 m (exactly at limit) → proceeds', () {
      final pts =
          points(n: 5, speedMs: 1.2, durationSec: 60, accuracy: 30.0);
      expect(classifier.classify(pts), isNot(equals(CellState.unexplored)),
          reason: '30 m is exactly at the limit — should be accepted');
    });

    test('3 points with accuracy 31 m → UNEXPLORED (too inaccurate)', () {
      final pts =
          points(n: 5, speedMs: 1.2, durationSec: 60, accuracy: 31.0);
      expect(classifier.classify(pts), equals(CellState.unexplored));
    });

    // GPS noise threshold: dwell < 5 s
    test('Dwell 4 s → UNEXPLORED (GPS noise rejection)', () {
      final pts = points(n: 5, speedMs: 0.5, durationSec: 4.0);
      expect(classifier.classify(pts), equals(CellState.unexplored));
    });

    test('Dwell exactly 5 s → passes noise filter → TRANSIT', () {
      final pts = points(n: 5, speedMs: 0.5, durationSec: 5.0);
      // Speed 0.5 m/s (walking), dwell = 5 s, not yet 45 s → TRANSIT
      expect(classifier.classify(pts), equals(CellState.transit));
    });
  });

  // BUG 3 guard: dwell accumulation only during active tracking
  group('Dwell time — pause awareness', () {
    test('Points only provided during active tracking (caller responsibility)', () {
      // ClassifierEngine itself is stateless — it only sees the points
      // it is given. The SessionManager is responsible for NOT feeding points
      // during a paused session. This test documents that contract.
      //
      // Given: 8 points spanning 60 s (simulate active tracking only)
      final pts = points(n: 8, speedMs: 1.2, durationSec: 60);
      // Should classify correctly
      expect(classifier.classify(pts), equals(CellState.explored));
      // No internal state was mutated — verify re-classification is pure
      expect(classifier.classify(pts), equals(CellState.explored));
    });
  });
}
