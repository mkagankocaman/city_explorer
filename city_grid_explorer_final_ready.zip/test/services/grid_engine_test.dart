// test/services/grid_engine_test.dart
//
// Tests for GeoMath and ClassifierEngine.
// Run with: flutter test
//
// Kızılay Square (PDF §10.4): lat 39.9208, lng 32.8541
import 'package:flutter_test/flutter_test.dart';
import 'package:city_grid_explorer/core/utils/geo_math.dart';
import 'package:city_grid_explorer/core/constants.dart';
import 'package:city_grid_explorer/services/classifier_engine.dart';
import 'package:city_grid_explorer/data/models/location_point.dart';
import 'package:city_grid_explorer/data/models/grid_cell.dart';

void main() {
  // ══════════════════════════════════════════════════════════
  // GeoMath tests
  // ══════════════════════════════════════════════════════════
  group('GeoMath — latLngToGrid', () {
    test('Kızılay Square maps to a deterministic cell (PDF §10.4)', () {
      // Kızılay Square, Ankara: 39.9208°N, 32.8541°E
      final (gridX, gridY) = GeoMath.latLngToGrid(39.9208, 32.8541);

      // Cell ID must be non-empty and follow "gridY_gridX" format
      final cellId = GeoMath.makeCellId(gridX, gridY);
      expect(cellId, isNotEmpty);
      expect(cellId.contains('_'), isTrue);
    });

    test('Points 2 metres apart map to the same cell', () {
      // 2 m difference — well within a 150 m cell
      final (x1, y1) = GeoMath.latLngToGrid(39.9208, 32.8541);
      // ~2 m north
      final (x2, y2) = GeoMath.latLngToGrid(39.9209, 32.8541);

      // Could be same row or adjacent — just confirm the math doesn't crash
      expect(x1, isA<int>());
      expect(y1, isA<int>());
      expect(x2, isA<int>());
      expect(y2, isA<int>());
    });

    test('Points 200 m apart are in different cells', () {
      // Two points ~200 m apart (greater than one 150 m cell)
      final (_, y1) = GeoMath.latLngToGrid(39.9208, 32.8541);
      // 200 m north ≈ 200/111320° ≈ 0.001797° latitude
      final (_, y2) = GeoMath.latLngToGrid(39.9208 + 0.001797, 32.8541);

      expect(y1, isNot(equals(y2)),
          reason: 'Points 200 m apart must be in different grid rows');
    });

    test('parseCellId round-trips through makeCellId', () {
      const gridX = 18678;
      const gridY = 29622;
      final cellId = GeoMath.makeCellId(gridX, gridY);
      final (parsedX, parsedY) = GeoMath.parseCellId(cellId);

      expect(parsedX, equals(gridX));
      expect(parsedY, equals(gridY));
    });

    test('gridToLatLng returns center inside the cell boundaries', () {
      const gridX = 18678;
      const gridY = 29622;
      final (centerLat, centerLng) = GeoMath.gridToLatLng(gridX, gridY);

      // Center should map back to the same cell
      final (cx, cy) = GeoMath.latLngToGrid(centerLat, centerLng);
      expect(cx, equals(gridX));
      expect(cy, equals(gridY));
    });

    test('deltaLat is approximately 0.001348°', () {
      // 150 m / 111320 m/° ≈ 0.001348°
      expect(GeoMath.deltaLat, closeTo(0.001348, 0.0001));
    });

    test('deltaLng at Ankara latitude is approximately 0.001758°', () {
      // At 39.93°N: 150 / (111320 × cos(39.93°)) ≈ 0.001758°
      expect(GeoMath.deltaLng(39.93), closeTo(0.001758, 0.0001));
    });
  });

  // ══════════════════════════════════════════════════════════
  // GeoMath — haversineDistance
  // ══════════════════════════════════════════════════════════
  group('GeoMath — haversineDistance', () {
    test('Kızılay to Ulus is approximately 2 km (PDF §10.4)', () {
      // Kızılay: 39.9208, 32.8541
      // Ulus:    39.9390, 32.8546  (~2 km north)
      final dist = GeoMath.haversineDistance(
        39.9208, 32.8541,
        39.9390, 32.8546,
      );
      // PDF says ~2025 m ± 100 m
      expect(dist, closeTo(2025, 150));
    });

    test('Zero distance for identical coordinates', () {
      final dist =
          GeoMath.haversineDistance(39.9208, 32.8541, 39.9208, 32.8541);
      expect(dist, closeTo(0.0, 0.001));
    });

    test('Distance is symmetric', () {
      final d1 = GeoMath.haversineDistance(39.9208, 32.8541, 39.9390, 32.8546);
      final d2 = GeoMath.haversineDistance(39.9390, 32.8546, 39.9208, 32.8541);
      expect(d1, closeTo(d2, 0.001));
    });

    test('150 m cell diagonal is < 220 m', () {
      // Cell corners: SW to NE diagonal of a 150 × 150 m cell
      final (gridX, gridY) = GeoMath.latLngToGrid(39.9208, 32.8541);
      final corners = GeoMath.cellCorners(gridX, gridY);

      final diag = GeoMath.haversineDistance(
        corners[0].$1, corners[0].$2, // SW
        corners[2].$1, corners[2].$2, // NE
      );
      // Pythagoras: √(150² + 150²) ≈ 212 m
      expect(diag, closeTo(212, 20));
    });
  });

  // ══════════════════════════════════════════════════════════
  // GeoMath — cellCorners
  // ══════════════════════════════════════════════════════════
  group('GeoMath — cellCorners', () {
    test('Returns 4 corners (SW, SE, NE, NW)', () {
      final corners = GeoMath.cellCorners(18678, 29622);
      expect(corners.length, equals(4));
    });

    test('SW corner has smaller lat AND lng than NE corner', () {
      final corners = GeoMath.cellCorners(18678, 29622);
      final sw = corners[0];
      final ne = corners[2];
      expect(sw.$1, lessThan(ne.$1), reason: 'SW lat < NE lat');
      expect(sw.$2, lessThan(ne.$2), reason: 'SW lng < NE lng');
    });

    test('Cell width is approximately 150 m', () {
      final corners = GeoMath.cellCorners(18678, 29622);
      final sw = corners[0];
      final se = corners[1];
      final width = GeoMath.haversineDistance(
          sw.$1, sw.$2, se.$1, se.$2);
      expect(width, closeTo(150, 15),
          reason: 'Cell should be ~150 m wide');
    });

    test('Cell height is approximately 150 m', () {
      final corners = GeoMath.cellCorners(18678, 29622);
      final sw = corners[0];
      final nw = corners[3];
      final height = GeoMath.haversineDistance(
          sw.$1, sw.$2, nw.$1, nw.$2);
      expect(height, closeTo(150, 15),
          reason: 'Cell should be ~150 m tall');
    });
  });

  // ══════════════════════════════════════════════════════════
  // ClassifierEngine
  // ══════════════════════════════════════════════════════════
  group('ClassifierEngine — classification', () {
    final classifier = ClassifierEngine.instance;

    /// Helper: build GPS points at a given speed inside a cell.
    List<LocationPoint> _makePoints({
      required int count,
      required double lat,
      required double lng,
      required double speedMs, // m/s
      required double durationSec,
      double accuracy = 10.0,
    }) {
      final now = DateTime.now();
      final points = <LocationPoint>[];
      final interval = durationSec / (count - 1);
      // Simulate movement at given speed along latitude
      final latStep = (speedMs * interval) / 111320.0;

      for (var i = 0; i < count; i++) {
        points.add(LocationPoint(
          sessionId: 'test_session',
          lat: lat + latStep * i,
          lng: lng,
          accuracy: accuracy,
          speed: speedMs,
          timestamp: now.add(Duration(
              milliseconds: (interval * i * 1000).round())),
        ));
      }
      return points;
    }

    // ── Unexplored cases ───────────────────────────────────────────
    test('Fewer than 3 points → UNEXPLORED', () {
      final points = _makePoints(
          count: 2, lat: 39.92, lng: 32.85, speedMs: 1.0, durationSec: 60);
      expect(classifier.classify(points), equals(CellState.unexplored));
    });

    test('All points with accuracy > 30 m → UNEXPLORED', () {
      final points = _makePoints(
          count: 5,
          lat: 39.92,
          lng: 32.85,
          speedMs: 1.0,
          durationSec: 60,
          accuracy: 50.0); // Worse than 30 m threshold
      expect(classifier.classify(points), equals(CellState.unexplored));
    });

    test('Dwell time < 5 s → UNEXPLORED (GPS noise)', () {
      final points = _makePoints(
          count: 5, lat: 39.92, lng: 32.85, speedMs: 1.0, durationSec: 3.0);
      expect(classifier.classify(points), equals(CellState.unexplored));
    });

    // ── Transit cases ──────────────────────────────────────────────
    test('Speed > 12 km/h (vehicle) with dwell ≥ 5 s → TRANSIT', () {
      // 15 km/h = 4.17 m/s — bus speed
      final points = _makePoints(
          count: 5, lat: 39.92, lng: 32.85, speedMs: 4.17, durationSec: 20);
      expect(classifier.classify(points), equals(CellState.transit));
    });

    test('Speed 7–12 km/h (running) → TRANSIT', () {
      // 10 km/h = 2.78 m/s — brisk jog
      final points = _makePoints(
          count: 5, lat: 39.92, lng: 32.85, speedMs: 2.78, durationSec: 30);
      expect(classifier.classify(points), equals(CellState.transit));
    });

    test('Walking speed but dwell < 45 s → TRANSIT', () {
      // 5 km/h = 1.39 m/s, but only 30 s in cell
      final points = _makePoints(
          count: 5, lat: 39.92, lng: 32.85, speedMs: 1.39, durationSec: 30);
      expect(classifier.classify(points), equals(CellState.transit));
    });

    // ── Explored cases ─────────────────────────────────────────────
    test('Walking speed + dwell ≥ 45 s → EXPLORED', () {
      // 5 km/h = 1.39 m/s, 60 s dwell — normal walk through a cell
      final points = _makePoints(
          count: 8, lat: 39.92, lng: 32.85, speedMs: 1.39, durationSec: 60);
      expect(classifier.classify(points), equals(CellState.explored));
    });

    test('Very slow walking (0.5 m/s) + dwell ≥ 45 s → EXPLORED', () {
      // Slow stroll or browsing a market
      final points = _makePoints(
          count: 8, lat: 39.92, lng: 32.85, speedMs: 0.5, durationSec: 90);
      expect(classifier.classify(points), equals(CellState.explored));
    });

    // ── Speed smoothing ────────────────────────────────────────────
    test('smoothedSpeed returns median, not mean', () {
      // 4 slow points + 1 fast outlier: mean would be high, median should be low
      final now = DateTime.now();
      final points = [
        LocationPoint(
            sessionId: 'x',
            lat: 39.920,
            lng: 32.854,
            accuracy: 10,
            timestamp: now),
        LocationPoint(
            sessionId: 'x',
            lat: 39.9201,
            lng: 32.854,
            accuracy: 10,
            timestamp: now.add(const Duration(seconds: 1))),
        LocationPoint(
            sessionId: 'x',
            lat: 39.9202,
            lng: 32.854,
            accuracy: 10,
            timestamp: now.add(const Duration(seconds: 2))),
        LocationPoint(
            sessionId: 'x',
            lat: 39.9203,
            lng: 32.854,
            accuracy: 10,
            timestamp: now.add(const Duration(seconds: 3))),
        // Speed outlier: jumps 500 m in 1 s (GPS glitch)
        LocationPoint(
            sessionId: 'x',
            lat: 39.9248,
            lng: 32.854,
            accuracy: 10,
            timestamp: now.add(const Duration(seconds: 4))),
      ];

      // Median speed should be close to the slow speed (~1.1 m/s), not the outlier
      final speed = classifier.smoothedSpeed(points);
      expect(speed, lessThan(5.0),
          reason: 'Median should suppress the high-speed outlier');
    });

    // ── BUG 1 guard: classification never inspects count including transit ──
    test('EXPLORED cells count separately from TRANSIT', () {
      // This test documents that CellState.explored.index == 2
      // and CellState.transit.index == 1 — achievement checks must use
      // countByState(CellState.explored), not a total count.
      expect(CellState.explored.dbValue, equals(2));
      expect(CellState.transit.dbValue, equals(1));
      expect(CellState.unexplored.dbValue, equals(0));
    });
  });
}
