// test/data/grid_repository_test.dart
//
// Tests for GridRepository — focuses on:
//   • BUG 1: achievement counting uses ONLY explored cells
//   • BUG 2: visitCount increments only on UPDATE, not INSERT
//
// Run with: flutter test
import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite/sqflite.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:city_grid_explorer/data/database/app_database.dart';
import 'package:city_grid_explorer/data/database/tables.dart';
import 'package:city_grid_explorer/data/models/grid_cell.dart';
import 'package:city_grid_explorer/data/repositories/grid_repository.dart';

/// Opens an in-memory SQLite database for tests (no file created).
Future<Database> openTestDb() async {
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfi;
  final db = await databaseFactory.openDatabase(
    inMemoryDatabasePath,
    options: OpenDatabaseOptions(
      version: 1,
      onCreate: (db, _) async {
        await db.execute(Tables.createGridCells);
        await db.execute(Tables.createGridCellsIndexXY);
      },
    ),
  );
  return db;
}

/// Minimal GridCell for testing.
GridCell _makeCell(
  String cellId,
  int gridX,
  int gridY,
  CellState state, {
  int totalDwellMs = 5000,
}) {
  return GridCell(
    cellId: cellId,
    gridX: gridX,
    gridY: gridY,
    centerLat: 39.9208,
    centerLng: 32.8541,
    state: state,
    firstVisited: DateTime(2026, 5, 1),
    lastVisited: DateTime(2026, 5, 1),
    visitCount: 1,
    totalDwellMs: totalDwellMs,
    sessionId: 'session_test',
  );
}

void main() {
  late AppDatabase appDb;
  late GridRepository repo;

  setUp(() async {
    // We can't easily mock AppDatabase, so we use the real singleton
    // but point it at an in-memory DB via sqflite_common_ffi.
    // For a production test suite, inject the DB via constructor.
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
    appDb = AppDatabase.instance;
    await appDb.initialize();
    repo = GridRepository(appDb);
  });

  tearDown(() async {
    await appDb.clearHistory();
  });

  // ══════════════════════════════════════════════════════════
  // BUG 1: Achievement counting
  // ══════════════════════════════════════════════════════════
  group('BUG 1 FIX — countByState counts ONLY the requested state', () {
    test('countByState(explored) returns 0 when only transit cells exist', () async {
      await repo.upsertCell(_makeCell('100_200', 200, 100, CellState.transit));
      await repo.upsertCell(_makeCell('101_200', 200, 101, CellState.transit));

      // BUG 1 FIX: This must return 0, not 2
      final exploredCount = await repo.countByState(CellState.explored);
      expect(exploredCount, equals(0),
          reason: 'Transit cells must NOT count toward explored achievements');
    });

    test('countByState(explored) counts only explored cells', () async {
      await repo.upsertCell(_makeCell('100_200', 200, 100, CellState.explored));
      await repo.upsertCell(_makeCell('101_200', 200, 101, CellState.transit));
      await repo.upsertCell(_makeCell('102_200', 200, 102, CellState.explored));

      final exploredCount = await repo.countByState(CellState.explored);
      expect(exploredCount, equals(2));

      final transitCount = await repo.countByState(CellState.transit);
      expect(transitCount, equals(1));
    });

    test('Mixing explored and transit cells gives correct separate counts', () async {
      // 3 explored + 2 transit
      for (var i = 0; i < 3; i++) {
        await repo.upsertCell(
            _makeCell('10${i}_100', 100, 100 + i, CellState.explored));
      }
      for (var i = 0; i < 2; i++) {
        await repo.upsertCell(
            _makeCell('20${i}_100', 100, 200 + i, CellState.transit));
      }

      expect(await repo.countByState(CellState.explored), equals(3));
      expect(await repo.countByState(CellState.transit), equals(2));
    });
  });

  // ══════════════════════════════════════════════════════════
  // BUG 2: visitCount double increment
  // ══════════════════════════════════════════════════════════
  group('BUG 2 FIX — visitCount increments only on UPDATE', () {
    test('First INSERT starts visitCount at 1', () async {
      await repo.upsertCell(
          _makeCell('300_400', 400, 300, CellState.explored));

      final cell = await repo.getCell('300_400');
      expect(cell, isNotNull);
      expect(cell!.visitCount, equals(1),
          reason: 'First visit should have visitCount = 1, not 2');
    });

    test('Second upsert (same cell) increments visitCount to 2', () async {
      await repo.upsertCell(
          _makeCell('300_400', 400, 300, CellState.transit));
      await repo.upsertCell(
          _makeCell('300_400', 400, 300, CellState.explored));

      final cell = await repo.getCell('300_400');
      expect(cell!.visitCount, equals(2),
          reason: 'Second visit increments to 2');
    });

    test('Third upsert increments visitCount to 3', () async {
      await repo.upsertCell(
          _makeCell('300_400', 400, 300, CellState.transit));
      await repo.upsertCell(
          _makeCell('300_400', 400, 300, CellState.transit));
      await repo.upsertCell(
          _makeCell('300_400', 400, 300, CellState.explored));

      final cell = await repo.getCell('300_400');
      expect(cell!.visitCount, equals(3));
    });
  });

  // ══════════════════════════════════════════════════════════
  // State transition: state can only go up (transit → explored), never down
  // ══════════════════════════════════════════════════════════
  group('State transitions — state never degrades', () {
    test('Transit cell upgraded to explored on re-visit', () async {
      await repo.upsertCell(
          _makeCell('500_600', 600, 500, CellState.transit));
      await repo.upsertCell(
          _makeCell('500_600', 600, 500, CellState.explored));

      final cell = await repo.getCell('500_600');
      expect(cell!.state, equals(CellState.explored));
    });

    test('Explored cell stays explored even if transit is upserted', () async {
      await repo.upsertCell(
          _makeCell('500_600', 600, 500, CellState.explored));
      // Subsequent transit reading should NOT downgrade the cell
      await repo.upsertCell(
          _makeCell('500_600', 600, 500, CellState.transit));

      final cell = await repo.getCell('500_600');
      expect(cell!.state, equals(CellState.explored),
          reason: 'Explored state must not be downgraded to transit');
    });
  });

  // ══════════════════════════════════════════════════════════
  // Dwell time accumulation
  // ══════════════════════════════════════════════════════════
  group('Dwell time accumulation', () {
    test('totalDwellMs sums across visits', () async {
      await repo.upsertCell(
          _makeCell('700_800', 800, 700, CellState.transit, totalDwellMs: 20000));
      await repo.upsertCell(
          _makeCell('700_800', 800, 700, CellState.explored, totalDwellMs: 30000));

      final cell = await repo.getCell('700_800');
      expect(cell!.totalDwellMs, equals(50000),
          reason: 'Dwell time should accumulate: 20000 + 30000 = 50000 ms');
    });
  });
}
